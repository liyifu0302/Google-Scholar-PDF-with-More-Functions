(function () {
  "use strict";

  const REF_ID_RE = String.raw`[A-Z]?\d+(?:[.-]\d+)?[A-Za-z]?|[IVXLCDM]+`;
  const SUPPLEMENT_PREFIX_RE = String.raw`(?:Supplement(?:ary|al)?|Supporting(?:\s+Information)?|Extended\s+Data)`;
  const TABLE_PREFIX_RE = String.raw`(?:Table|Tab\.?)`;
  const FIGURE_PREFIX_RE = String.raw`(?:Figure|Fig\.?)`;
  const APPENDIX_PREFIX_RE = String.raw`(?:Online\s+)?Appendix`;
  const REF_RE = new RegExp(
    String.raw`\b(?:${SUPPLEMENT_PREFIX_RE}\s+)?${TABLE_PREFIX_RE}\s*(${REF_ID_RE})\b|` +
      String.raw`\b(?:${SUPPLEMENT_PREFIX_RE}\s+)?${FIGURE_PREFIX_RE}\s*(${REF_ID_RE})\b|` +
      String.raw`\b(?:(?:${SUPPLEMENT_PREFIX_RE}|SI)\s+)?${APPENDIX_PREFIX_RE}(?:\s+(?:${TABLE_PREFIX_RE}|${FIGURE_PREFIX_RE}))?\s*([A-Z]\d*|[0-9]+[A-Za-z]?)\b|` +
      String.raw`\u8868\s*([0-9]+|[\u4e00\u4e8c\u4e09\u56db\u4e94\u516d\u4e03\u516b\u4e5d\u5341\u767e]+)`,
    "gi"
  );
  const CAPTION_RE = new RegExp(String.raw`^\s*(?:${SUPPLEMENT_PREFIX_RE}\s+)?${TABLE_PREFIX_RE}\s*(${REF_ID_RE})\b(.*)$`, "i");
  const FIGURE_CAPTION_RE = new RegExp(String.raw`^\s*(?:${SUPPLEMENT_PREFIX_RE}\s+)?${FIGURE_PREFIX_RE}\s*(${REF_ID_RE})\b(.*)$`, "i");
  const APPENDIX_CAPTION_RE = new RegExp(String.raw`^\s*(?:(?:${SUPPLEMENT_PREFIX_RE}|SI)\s+)?${APPENDIX_PREFIX_RE}(?:\s+(?:${TABLE_PREFIX_RE}|${FIGURE_PREFIX_RE}))?\s*([A-Z]\d*|[0-9]+[A-Za-z]?)\b(.*)$`, "i");
  const CAPTION_ZH_RE = /^\s*\u8868\s*([0-9]+|[\u4e00\u4e8c\u4e09\u56db\u4e94\u516d\u4e03\u516b\u4e5d\u5341\u767e]+)(.*)$/;
  const CAPTION_PREFIX_RE = new RegExp(
    String.raw`^\s*(?:(?:${SUPPLEMENT_PREFIX_RE}\s+)?(?:${TABLE_PREFIX_RE}|${FIGURE_PREFIX_RE})|(?:(?:${SUPPLEMENT_PREFIX_RE}|SI)\s+)?${APPENDIX_PREFIX_RE}|\u8868)` ,
    "i"
  );
  const PROSE_TABLE_TAIL_RE = /^[\s,;:.\-\u2013\u2014]*(?:(?:panel|column|appendix|section)\s+[a-z0-9]+\s+)?(?:reports?|shows?|presents?|summari[sz]es?|lists?|contains?|provides?|documents?|describes?|compares?|indicates?|suggests?|reveals?|demonstrates?|includes?|estimates?|examines?|uses?|displays?|gives?|plots?|depicts?|illustrates?|graphs?|visuali[sz]es?|traces?)\b/i;
  const PROSE_TABLE_SENTENCE_RE = /\b(?:reports?|shows?|presents?|summari[sz]es?|documents?|describes?|compares?|indicates?|suggests?|reveals?|demonstrates?|estimates?|examines?|plots?|depicts?|illustrates?|graphs?|visuali[sz]es?|traces?)\s+(?:the|that|how|my|our|their|these|those|results?|tests?|models?|analysis|statistics|descriptive|effect|effects)\b/i;
  const MAX_INDEX_WORKERS = 3;
  const MAX_PREVIEW_EDGE = 3200;
  const MAX_JUMP_HISTORY = 32;
  const MIN_PREVIEW_WIDTH = 360;
  const MIN_PREVIEW_HEIGHT = 220;
  const ANNOTATE_VIEWPORT_MARGIN = 120;
  const ENABLE_ATTACHMENT_PREVIEWS = false;
  const STORAGE_KEY = "gsr-table-ref-mode";
  const MODE_PREVIEW = "preview";
  const MODE_JUMP = "jump";

  const state = {
    api: null,
    readerPromise: null,
    index: null,
    indexPromise: null,
    scheduled: false,
    preview: null,
    previewWindows: new Set(),
    previewZ: 40,
    previewCascade: 0,
    hideTimer: 0,
    indexBuildTimer: 0,
    token: 0,
    heldPage: 0,
    mode: loadMode(),
    modeTools: null,
    resizeObserver: null,
    observedElements: new WeakSet(),
    docApiRef: null,
    docReaderRef: null,
    pdfjs: null,
    pdfjsPromise: null,
    mainPdfBytes: null,
    mainPdfBytesPromise: null,
    attachmentDocs: null,
    attachmentDocsPromise: null,
    jumpHistory: []
  };

  function loadMode() {
    try {
      return localStorage.getItem(STORAGE_KEY) === MODE_JUMP ? MODE_JUMP : MODE_PREVIEW;
    } catch (error) {
      return MODE_PREVIEW;
    }
  }

  function saveMode() {
    try {
      localStorage.setItem(STORAGE_KEY, state.mode);
    } catch (error) {
      console.warn("Google Scholar Reader table preview: unable to save mode", error);
    }
  }

  function yieldToBrowser() {
    return new Promise(resolve => setTimeout(resolve, 0));
  }

  function romanToInt(value) {
    const roman = String(value || "").toUpperCase();
    if (!/^[IVXLCDM]+$/.test(roman)) {
      return null;
    }
    const values = {
      I: 1,
      V: 5,
      X: 10,
      L: 50,
      C: 100,
      D: 500,
      M: 1000
    };
    let total = 0;
    let previous = 0;
    for (let index = roman.length - 1; index >= 0; index--) {
      const current = values[roman[index]] || 0;
      if (!current) {
        return null;
      }
      if (current < previous) {
        total -= current;
      } else {
        total += current;
        previous = current;
      }
    }
    return total > 0 ? String(total) : null;
  }

  function normalizeId(value) {
    const normalized = String(value || "")
      .trim()
      .replace(/\s+/g, "")
      .replace(/[.:;,\-\u2013\u2014]+$/g, "")
      .toLowerCase();
    return romanToInt(normalized) || normalized;
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function invalidateRenderedLayers() {
    for (const layer of document.querySelectorAll(".gsr-table-ref-layer")) {
      layer.textContent = "";
      delete layer.dataset.signature;
    }
  }

  function resetDocumentCaches() {
    if (state.indexBuildTimer) {
      clearTimeout(state.indexBuildTimer);
      state.indexBuildTimer = 0;
    }
    state.index = null;
    state.indexPromise = null;
    state.mainPdfBytes = null;
    state.mainPdfBytesPromise = null;
    state.attachmentDocs = null;
    state.attachmentDocsPromise = null;
    state.readerPromise = null;
    state.jumpHistory = [];
    closeAllPreviews();
    invalidateRenderedLayers();
  }

  function syncCurrentDocument() {
    const api = window.__gsrTablePreviewApi || null;
    const reader = window.__gsrReader || null;
    const changed = api !== state.docApiRef || reader !== state.docReaderRef;
    if (changed) {
      resetDocumentCaches();
      state.docApiRef = api;
      state.docReaderRef = reader;
    }
    state.api = api;
    return changed;
  }

  async function ensureCurrentDocument() {
    const [api, reader] = await Promise.all([waitForApi(), waitForReader()]);
    const changed = api !== state.docApiRef || reader !== state.docReaderRef;
    if (changed) {
      resetDocumentCaches();
      state.docApiRef = api || null;
      state.docReaderRef = reader || null;
    }
    state.api = api || null;
    return { api: state.api, reader, changed };
  }

  function waitForApi() {
    if (window.__gsrTablePreviewApi) {
      state.api = window.__gsrTablePreviewApi;
      return Promise.resolve(state.api);
    }
    return new Promise(resolve => {
      const started = Date.now();
      const timer = setInterval(function () {
        if (window.__gsrTablePreviewApi || Date.now() - started > 15000) {
          clearInterval(timer);
          state.api = window.__gsrTablePreviewApi || null;
          resolve(state.api);
        }
      }, 100);
    });
  }

  async function waitForReader() {
    if (window.__gsrReader) {
      return window.__gsrReader;
    }
    if (state.readerPromise) {
      return state.readerPromise;
    }
    state.readerPromise = (async function () {
      await waitForApi();
      if (window.__gsrReader) {
        return window.__gsrReader;
      }
      return new Promise(resolve => {
        const started = Date.now();
        const timer = setInterval(function () {
          if (window.__gsrReader || Date.now() - started > 15000) {
            clearInterval(timer);
            resolve(window.__gsrReader || null);
          }
        }, 100);
      });
    })();
    return state.readerPromise;
  }

  async function loadPdfJs() {
    if (state.pdfjs) {
      return state.pdfjs;
    }
    if (state.pdfjsPromise) {
      return state.pdfjsPromise;
    }
    state.pdfjsPromise = new Promise((resolve, reject) => {
      if (window.pdfjsLib) {
        resolve(window.pdfjsLib);
        return;
      }
      const existing = document.querySelector('script[data-gsr-pdfjs="1"]');
      if (existing) {
        existing.addEventListener("load", function handleLoad() {
          existing.removeEventListener("load", handleLoad);
          resolve(window.pdfjsLib || null);
        });
        existing.addEventListener("error", function handleError() {
          existing.removeEventListener("error", handleError);
          reject(new Error("Failed to load pdf.js"));
        });
        return;
      }
      const script = document.createElement("script");
      script.src = "/pdf.min.js";
      script.defer = true;
      script.dataset.gsrPdfjs = "1";
      script.addEventListener("load", function handleLoad() {
        script.removeEventListener("load", handleLoad);
        resolve(window.pdfjsLib || null);
      });
      script.addEventListener("error", function handleError() {
        script.removeEventListener("error", handleError);
        reject(new Error("Failed to load pdf.js"));
      });
      document.head.appendChild(script);
    }).then(pdfjs => {
      if (pdfjs && pdfjs.GlobalWorkerOptions) {
        pdfjs.GlobalWorkerOptions.workerSrc = "/pdf.worker.min.js";
      }
      state.pdfjs = pdfjs || null;
      return state.pdfjs;
    }).catch(error => {
      console.warn("Google Scholar Reader table preview: unable to load pdf.js", error);
      return null;
    });
    return state.pdfjsPromise;
  }

  function getUint8Array(data) {
    if (!data) {
      return null;
    }
    if (data instanceof Uint8Array) {
      return data;
    }
    if (ArrayBuffer.isView(data)) {
      return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
    }
    if (data instanceof ArrayBuffer) {
      return new Uint8Array(data);
    }
    if (Array.isArray(data)) {
      return Uint8Array.from(data, value => Number(value) & 0xff);
    }
    if (typeof data === "string") {
      const bytes = new Uint8Array(data.length);
      for (let i = 0; i < data.length; i++) {
        bytes[i] = data.charCodeAt(i) & 0xff;
      }
      return bytes;
    }
    if (typeof data === "object") {
      if (Array.isArray(data.data)) {
        return Uint8Array.from(data.data, value => Number(value) & 0xff);
      }
      if (typeof data.length === "number" && Number.isFinite(data.length) && data.length >= 0) {
        const bytes = new Uint8Array(data.length);
        for (let i = 0; i < data.length; i++) {
          const value = data[i];
          if (typeof value !== "number") {
            return null;
          }
          bytes[i] = value & 0xff;
        }
        return bytes;
      }
    }
    return null;
  }

  function looksLikePdfAttachment(filename, content) {
    if (typeof filename === "string" && /\.pdf$/i.test(filename.trim())) {
      return true;
    }
    const bytes = getUint8Array(content);
    if (!bytes || bytes.length < 4) {
      return false;
    }
    for (let i = 0; i <= Math.min(bytes.length - 4, 1024); i++) {
      if (bytes[i] === 0x25 && bytes[i + 1] === 0x50 && bytes[i + 2] === 0x44 && bytes[i + 3] === 0x46) {
        return true;
      }
    }
    return false;
  }

  async function getMainPdfBytes() {
    if (state.mainPdfBytes) {
      return state.mainPdfBytes;
    }
    if (state.mainPdfBytesPromise) {
      return state.mainPdfBytesPromise;
    }
    state.mainPdfBytesPromise = (async function () {
      const reader = await waitForReader();
      if (!reader || !reader.F || typeof reader.F.D !== "function") {
        return null;
      }
      try {
        const bytes = await reader.F.D();
        state.mainPdfBytes = bytes || null;
        return state.mainPdfBytes;
      } catch (error) {
        console.warn("Google Scholar Reader table preview: unable to load PDF bytes", error);
        return null;
      }
    })();
    return state.mainPdfBytesPromise;
  }

  async function getAttachmentDocs() {
    if (state.attachmentDocs) {
      return state.attachmentDocs;
    }
    if (state.attachmentDocsPromise) {
      return state.attachmentDocsPromise;
    }
    state.attachmentDocsPromise = (async function () {
      const [pdfjs, bytes] = await Promise.all([loadPdfJs(), getMainPdfBytes()]);
      if (!pdfjs || !bytes) {
        return [];
      }

      const loadingTask = pdfjs.getDocument({ data: bytes });
      try {
        const doc = await loadingTask.promise;
        const attachments = await doc.getAttachments();
        if (!attachments) {
          state.attachmentDocs = [];
          return state.attachmentDocs;
        }

        const docs = [];
        let index = 0;
        for (const [name, attachment] of Object.entries(attachments)) {
          const filename = (attachment && attachment.filename) || name || "Attachment " + (index + 1);
          const content = getUint8Array(attachment && attachment.content);
          if (!content || !looksLikePdfAttachment(filename, content)) {
            index++;
            continue;
          }
          try {
            const attachmentTask = pdfjs.getDocument({ data: content });
            const pdf = await attachmentTask.promise;
            docs.push({
              id: "attachment:" + index,
              name: filename,
              pdf,
              pages: new Map()
            });
          } catch (error) {
            console.warn("Google Scholar Reader table preview: unable to open attachment PDF", filename, error);
          }
          index++;
        }

        state.attachmentDocs = docs;
        return docs;
      } catch (error) {
        console.warn("Google Scholar Reader table preview: attachment scan failed", error);
        state.attachmentDocs = [];
        return state.attachmentDocs;
      } finally {
        try {
          await loadingTask.destroy();
        } catch (error) {
        }
      }
    })();
    return state.attachmentDocsPromise;
  }

  async function getAttachmentTextPage(attachment, pageNumber) {
    const page = clamp(pageNumber, 1, attachment.pdf.numPages);
    if (attachment.pages.has(page)) {
      return attachment.pages.get(page);
    }

    const pdfjs = await loadPdfJs();
    if (!pdfjs) {
      return null;
    }

    const pdfPage = await attachment.pdf.getPage(page);
    try {
      const viewport = pdfPage.getViewport({ scale: 1 });
      const textContent = await pdfPage.getTextContent();
      const items = [];
      for (const item of textContent.items || []) {
        if (!item || !item.str) {
          continue;
        }
        const transform = pdfjs.Util.transform(viewport.transform, item.transform);
        const width = Math.max(0, (item.width || 0) * viewport.scale);
        const height = Math.max(0, (item.height || 0) * viewport.scale);
        items.push({
          text: item.str,
          eol: item.hasEOL ? 1 : 0,
          left: transform[4],
          top: transform[5] - height,
          width,
          height,
          angle: Math.atan2(transform[1], transform[0])
        });
      }
      const pageData = {
        page,
        width: viewport.width,
        height: viewport.height,
        items
      };
      attachment.pages.set(page, pageData);
      return pageData;
    } finally {
      try {
        pdfPage.cleanup();
      } catch (error) {
      }
    }
  }

  function getIndexRotation(pageData) {
    if (!pageData || !Array.isArray(pageData.items) || !pageData.items.length) {
      return 0;
    }

    let horizontalWeight = 0;
    let positiveVerticalWeight = 0;
    let negativeVerticalWeight = 0;
    for (const item of pageData.items) {
      if (!item || !item.text || !item.text.trim()) {
        continue;
      }
      const angle = Number(item.angle) || 0;
      const absAngle = normalizePreviewAngle(angle);
      const weight = Math.max(1, item.width * item.height) * Math.max(1, item.text.trim().length);
      if (Math.abs(absAngle - 90) <= 18) {
        if (angle >= 0) {
          positiveVerticalWeight += weight;
        } else {
          negativeVerticalWeight += weight;
        }
      } else if (absAngle <= 18) {
        horizontalWeight += weight;
      }
    }

    const verticalWeight = positiveVerticalWeight + negativeVerticalWeight;
    if (verticalWeight <= Math.max(horizontalWeight * 1.2, 1600)) {
      return 0;
    }
    const fallbackRotation = positiveVerticalWeight >= negativeVerticalWeight ? 90 : 270;
    return chooseBestIndexRotation(pageData, fallbackRotation);
  }

  function rotatePageItem(item, pageData, rotation) {
    if (!rotation) {
      return {
        text: item.text,
        eol: item.eol,
        left: item.left,
        top: item.top,
        width: item.width,
        height: item.height,
        angle: item.angle
      };
    }

    if (rotation === 90) {
      return {
        text: item.text,
        eol: item.eol,
        left: pageData.height - (item.top + item.height),
        top: item.left,
        width: item.height,
        height: item.width,
        angle: item.angle - Math.PI / 2
      };
    }

    return {
      text: item.text,
      eol: item.eol,
      left: item.top,
      top: pageData.width - (item.left + item.width),
      width: item.height,
      height: item.width,
      angle: item.angle + Math.PI / 2
    };
  }

  function scoreIndexRotation(pageData, rotation) {
    if (!pageData || !Array.isArray(pageData.items) || !pageData.items.length) {
      return -Infinity;
    }
    const rotatedItems = pageData.items.map(item => rotatePageItem(item, pageData, rotation));
    const lines = makeLines(rotatedItems);
    const rotatedHeight = rotation ? pageData.width : pageData.height;
    let score = 0;
    for (let index = 0; index < Math.min(lines.length, 24); index++) {
      const line = lines[index];
      if (!line || !line.text) {
        continue;
      }
      let lineScore = 0;
      if (getCaptionTarget(line.text, { allowBodyStyleLead: true })) {
        lineScore += 40;
      } else if (isCaptionStart(line.text)) {
        lineScore += 16;
      }
      const refMatches = getRefMatches(line.text);
      if (refMatches.length) {
        lineScore += Math.min(3, refMatches.length) * 6;
      }
      if (/[A-Za-z]{3,}/.test(line.text)) {
        lineScore += 1;
      }
      if (Number.isFinite(line.bounds && line.bounds.top) && line.bounds.top <= Math.max(rotatedHeight * 0.3, 180)) {
        lineScore *= 1.4;
      }
      score += lineScore;
    }
    return score;
  }

  function chooseBestIndexRotation(pageData, fallbackRotation) {
    let bestRotation = fallbackRotation;
    let bestScore = -Infinity;
    for (const rotation of [90, 270]) {
      const score = scoreIndexRotation(pageData, rotation);
      if (score > bestScore + 1) {
        bestScore = score;
        bestRotation = rotation;
        continue;
      }
      if (Math.abs(score - bestScore) <= 1 && rotation === fallbackRotation) {
        bestRotation = rotation;
      }
    }
    return bestRotation;
  }

  function getIndexPageData(pageData) {
    if (!pageData) {
      return null;
    }

    const pageRotation = getIndexRotation(pageData);
    if (!pageRotation) {
      return {
        page: pageData.page,
        width: pageData.width,
        height: pageData.height,
        items: pageData.items,
        pageRotation: 0
      };
    }

    return {
      page: pageData.page,
      width: pageData.height,
      height: pageData.width,
      items: pageData.items.map(item => rotatePageItem(item, pageData, pageRotation)),
      pageRotation
    };
  }

  function getAttachmentIndexRotation(pageData) {
    return getIndexRotation(pageData);
  }

  function rotateAttachmentItem(item, pageData, rotation) {
    return rotatePageItem(item, pageData, rotation);
  }

  function getAttachmentIndexPageData(pageData) {
    return getIndexPageData(pageData);
  }

  async function renderAttachmentPageCanvas(attachment, pageNumber, rotation) {
    const page = await attachment.pdf.getPage(clamp(pageNumber, 1, attachment.pdf.numPages));
    try {
      const pageRotation = Number.isFinite(rotation) ? rotation : 0;
      const baseViewport = page.getViewport({ scale: 1, rotation: pageRotation });
      const scale = Math.min(1, MAX_PREVIEW_EDGE / Math.max(baseViewport.width, baseViewport.height));
      const viewport = page.getViewport({ scale: Math.max(scale, 0.25), rotation: pageRotation });
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(viewport.width));
      canvas.height = Math.max(1, Math.round(viewport.height));
      const context = canvas.getContext("2d", { alpha: false });
      await page.render({ canvasContext: context, viewport }).promise;
      return canvas;
    } finally {
      try {
        page.cleanup();
      } catch (error) {
      }
    }
  }

  function makeModeButton(className, mode, label, shortLabel, svg) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "gsr-table-mode-button " + className;
    button.dataset.tableMode = mode;
    const icon = document.createElement("span");
    icon.className = "gsr-table-mode-button-icon";
    icon.innerHTML = svg;
    const text = document.createElement("span");
    text.className = "gsr-table-mode-button-label";
    text.textContent = shortLabel;
    button.append(icon, text);
    button.setAttribute("aria-label", label);
    button.title = label;
    button.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      setMode(mode);
      scheduleAnnotate();
    });
    return button;
  }

  function installToolbar() {
    const host = document.querySelector(".gsr-tb-rt") || document.querySelector(".gsr-tb-ctr");
    if (!host || document.querySelector(".gsr-table-mode-tools")) {
      syncToolbarBrandIcon();
      updateModeUi();
      return;
    }

    const tools = document.createElement("span");
    tools.className = "gsr-table-mode-tools";
    const previewButton = makeModeButton(
      "gsr-table-mode-preview",
      MODE_PREVIEW,
      "Hover table, figure, and appendix references to preview",
      "Preview",
      '<svg viewBox="0 0 21 21"><path d="M3.5 4.5H17.5V16.5H3.5V4.5ZM5 6V9H9.8V6H5ZM11.2 6V9H16V6H11.2ZM5 10.3V15H9.8V10.3H5ZM11.2 10.3V15H16V10.3H11.2Z"/><path d="M10.5 13.7C12.5 10.8 15.9 10.8 17.9 13.7C15.9 16.6 12.5 16.6 10.5 13.7ZM14.2 12.4C13.5 12.4 12.9 13 12.9 13.7C12.9 14.4 13.5 15 14.2 15C14.9 15 15.5 14.4 15.5 13.7C15.5 13 14.9 12.4 14.2 12.4Z"/></svg>'
    );
    const jumpButton = makeModeButton(
      "gsr-table-mode-jump",
      MODE_JUMP,
      "Click table, figure, and appendix references to jump",
      "Jump",
      '<svg viewBox="0 0 21 21"><path d="M3.5 4.5H13.5V14.5H3.5V4.5ZM5 6V8.6H8V6H5ZM9.3 6V8.6H12V6H9.3ZM5 9.9V13H8V9.9H5ZM9.3 9.9V13H12V9.9H9.3Z"/><path d="M14.4 9L13.3 10.1L15.7 12.5H10V14H15.7L13.3 16.4L14.4 17.5L18.7 13.2L14.4 9Z"/></svg>'
    );

    tools.append(previewButton, jumpButton);
    host.insertBefore(tools, host.firstChild || null);
    state.modeTools = tools;
    syncToolbarBrandIcon();
    updateModeUi();
  }

  function syncToolbarBrandIcon() {
    const logo = document.querySelector(".gsr-tb-logo");
    if (!logo || logo.dataset.gsrBrandIcon === "true") {
      return;
    }

    const image = document.createElement("img");
    image.className = "gsr-tb-logo-image";
    image.alt = "GS Enhance";
    image.draggable = false;
    try {
      image.src = chrome.runtime.getURL("icon48.png");
    } catch (error) {
      image.src = "icon48.png";
    }

    logo.textContent = "";
    logo.appendChild(image);
    logo.dataset.gsrBrandIcon = "true";
  }

  function setMode(mode) {
    state.mode = mode === MODE_JUMP ? MODE_JUMP : MODE_PREVIEW;
    saveMode();
    closePreview();
    updateModeUi();
    updateRefModes();
  }

  function updateModeUi() {
    document.body.classList.toggle("gsr-table-jump-mode", state.mode === MODE_JUMP);
    document.querySelector(".gsr-root")?.classList.toggle("gsr-table-jump-mode", state.mode === MODE_JUMP);
    for (const button of document.querySelectorAll(".gsr-table-mode-tools [data-table-mode]")) {
      const selected = button.dataset.tableMode === state.mode;
      button.classList.toggle("gsr-select", selected);
      button.setAttribute("aria-pressed", selected ? "true" : "false");
    }
  }

  async function waitForDocumentReady(api) {
    const started = Date.now();
    while (api && api.numPages() <= 0 && Date.now() - started < 15000) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }

  function lineText(items) {
    let text = "";
    let previous = null;
    for (const item of items) {
      const part = item.text || "";
      if (!part) {
        continue;
      }
      if (previous && text && !/\s$/.test(text) && !/^\s/.test(part)) {
        const gap = item.left - (previous.left + previous.width);
        if (gap > Math.max(1.5, item.height * 0.16)) {
          text += " ";
        }
      }
      text += part;
      previous = item;
    }
    return text.replace(/\s+/g, " ").trim();
  }

  function normalizeCaptionText(text) {
    let value = String(text || "").replace(/\s+/g, " ").trim();
    value = value
      .replace(/\bS\s*U\s*P\s*P\s*L\s*E\s*M\s*E\s*N\s*T\s*A\s*R\s*Y\b/gi, "Supplementary")
      .replace(/\bS\s*U\s*P\s*P\s*L\s*E\s*M\s*E\s*N\s*T\s*A\s*L\b/gi, "Supplemental")
      .replace(/\bS\s*U\s*P\s*P\s*O\s*R\s*T\s*I\s*N\s*G\b/gi, "Supporting")
      .replace(/\bI\s*N\s*F\s*O\s*R\s*M\s*A\s*T\s*I\s*O\s*N\b/gi, "Information")
      .replace(/\bE\s*X\s*T\s*E\s*N\s*D\s*E\s*D\b/gi, "Extended")
      .replace(/\bD\s*A\s*T\s*A\b/gi, "Data")
      .replace(/\bT\s*A\s*B\s*L\s*E\b/gi, "Table")
      .replace(/\bT\s*A\s*B\.?\b/gi, "Tab")
      .replace(/\bF\s*I\s*G\s*U\s*R\s*E\b/gi, "Figure")
      .replace(/\bF\s*I\s*G\.?\b/gi, "Fig")
      .replace(/\bO\s*N\s*L\s*I\s*N\s*E\b/gi, "Online")
      .replace(/\bA\s*P\s*P\s*E\s*N\s*D\s*I\s*X\b/gi, "Appendix");
    return value;
  }

  function mergeBounds(items) {
    let left = Infinity;
    let top = Infinity;
    let right = -Infinity;
    let bottom = -Infinity;
    for (const item of items) {
      left = Math.min(left, item.left);
      top = Math.min(top, item.top);
      right = Math.max(right, item.left + item.width);
      bottom = Math.max(bottom, item.top + item.height);
    }
    return {
      left,
      top,
      width: Math.max(0, right - left),
      height: Math.max(0, bottom - top)
    };
  }

  function makeLines(items) {
    const visible = (items || [])
      .filter(item => item.text && item.text.trim() && Number.isFinite(item.left) && Number.isFinite(item.top))
      .sort((a, b) => a.top - b.top || a.left - b.left);
    const rows = [];
    for (const item of visible) {
      const row = rows[rows.length - 1];
      const tolerance = Math.max(2, Math.min(8, Math.max(item.height || 0, row ? row.height : 0) * 0.7));
      if (row && Math.abs(item.top - row.top) <= tolerance) {
        row.items.push(item);
        row.top = (row.top * (row.items.length - 1) + item.top) / row.items.length;
        row.height = Math.max(row.height, item.height || 0);
      } else {
        rows.push({ top: item.top, height: item.height || 0, items: [item] });
      }
    }
    return rows.map(row => {
      row.items.sort((a, b) => a.left - b.left);
      const heights = row.items.map(item => Math.max(0, item.height || 0)).filter(Boolean);
      const avgHeight = heights.length ? heights.reduce((sum, value) => sum + value, 0) / heights.length : 0;
      return {
        text: lineText(row.items),
        bounds: mergeBounds(row.items),
        items: row.items,
        avgHeight
      };
    }).filter(line => line.text);
  }

  function isCaptionStart(text) {
    return CAPTION_PREFIX_RE.test(normalizeCaptionText(text));
  }

  function mergeLineGroup(lines, start, end) {
    const group = lines.slice(start, end + 1);
    const items = [];
    const parts = [];
    for (const line of group) {
      if (!line) {
        continue;
      }
      if (line.text) {
        parts.push(line.text);
      }
      if (Array.isArray(line.items)) {
        items.push(...line.items);
      }
    }
    const heights = items.map(item => Math.max(0, item.height || 0)).filter(Boolean);
    return {
      text: parts.join(" ").replace(/\s+/g, " ").trim(),
      bounds: mergeBounds(items),
      items,
      avgHeight: heights.length ? heights.reduce((sum, value) => sum + value, 0) / heights.length : 0
    };
  }

  function makeCaptionCandidate(candidate, startIndex, endIndex) {
    return {
      text: candidate.text,
      bounds: candidate.bounds,
      items: candidate.items,
      avgHeight: candidate.avgHeight || 0,
      startIndex,
      endIndex
    };
  }

  function getCaptionCandidates(lines) {
    const candidates = [];
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (!line || !line.text) {
        continue;
      }
      candidates.push(makeCaptionCandidate(line, i, i));
      if (!isCaptionStart(line.text)) {
        continue;
      }
      for (let end = i + 1; end < Math.min(lines.length, i + 3); end++) {
        const merged = mergeLineGroup(lines, i, end);
        if (merged.text && merged.text !== line.text) {
          candidates.push(makeCaptionCandidate(merged, i, end));
        }
      }
    }
    return candidates;
  }

  function isBodyStyleCaptionText(text) {
    const value = normalizeCaptionText(text);
    const match = CAPTION_RE.exec(value) || FIGURE_CAPTION_RE.exec(value) || APPENDIX_CAPTION_RE.exec(value) || CAPTION_ZH_RE.exec(value);
    const tail = match ? String(match[2] || "") : "";
    const normalizedTail = tail.replace(/\s+/g, " ").trim();
    if (hasCaptionLeadPunctuation(normalizedTail)) {
      return false;
    }
    return /^(?:reports?|shows?|presents?|summari[sz]es?|lists?|contains?|provides?|documents?|describes?|compares?|indicates?|suggests?|reveals?|demonstrates?|includes?|estimates?|examines?|uses?|displays?|gives?)\b/i.test(normalizedTail);
  }

  function getCaptionTailText(text) {
    const value = normalizeCaptionText(text);
    const match = CAPTION_RE.exec(value) || FIGURE_CAPTION_RE.exec(value) || APPENDIX_CAPTION_RE.exec(value) || CAPTION_ZH_RE.exec(value);
    return match ? String(match[2] || "").replace(/^[\s.:;\-\u2013\u2014]+/, "").trim() : "";
  }

  function hasCaptionLeadPunctuation(tail) {
    return /^[.:\-\u2013\u2014]\s*/.test(String(tail || "").trimStart());
  }

  function isContinuedCaptionText(text) {
    return /\b(?:continued|continuation|cont\.?|cont'd)\b/i.test(String(text || ""));
  }

  function isTopPageCaptionEntry(entry) {
    const top = Number.isFinite(entry && entry.top) ? entry.top : Infinity;
    const pageHeight = Number.isFinite(entry && entry.pageHeight) ? entry.pageHeight : 0;
    return pageHeight > 0 && top <= Math.max(pageHeight * 0.22, 150);
  }

  function shouldReplaceTable(existing, candidate) {
    if (!existing) {
      return true;
    }
    const existingScore = Number.isFinite(existing.score) ? existing.score : 0;
    const candidateScore = Number.isFinite(candidate.score) ? candidate.score : 0;
    const existingOrder = (Number(existing.page) || 0) * 100000 + (Number(existing.top) || 0);
    const candidateOrder = (Number(candidate.page) || 0) * 100000 + (Number(candidate.top) || 0);
    const existingTail = getCaptionTailText(existing.text);
    const candidateTail = getCaptionTailText(candidate.text);
    const existingPunctuated = hasCaptionLeadPunctuation((existing.text || "").replace(/^\s*(?:Supplement(?:ary|al)?|Supporting(?:\s+Information)?|Extended\s+Data\s+)?(?:Table|Tab\.?|Figure|Fig\.?|Online\s+Appendix|Appendix|\u8868)\s*(?:[A-Z]?\d+(?:[.-]\d+)?[A-Za-z]?|[IVXLCDM]+|[\u4e00\u4e8c\u4e09\u56db\u4e94\u516d\u4e03\u516b\u4e5d\u5341\u767e]+)/i, ""));
    const candidatePunctuated = hasCaptionLeadPunctuation((candidate.text || "").replace(/^\s*(?:Supplement(?:ary|al)?|Supporting(?:\s+Information)?|Extended\s+Data\s+)?(?:Table|Tab\.?|Figure|Fig\.?|Online\s+Appendix|Appendix|\u8868)\s*(?:[A-Z]?\d+(?:[.-]\d+)?[A-Za-z]?|[IVXLCDM]+|[\u4e00\u4e8c\u4e09\u56db\u4e94\u516d\u4e03\u516b\u4e5d\u5341\u767e]+)/i, ""));
    const existingBodyStyle = isBodyStyleCaptionText(existing.text);
    const candidateBodyStyle = isBodyStyleCaptionText(candidate.text);
    const existingContinued = isContinuedCaptionText(existing.text);
    const candidateContinued = isContinuedCaptionText(candidate.text);
    const existingTopCaption = isTopPageCaptionEntry(existing);
    if (existingContinued !== candidateContinued) {
      return !candidateContinued;
    }
    if (existingPunctuated !== candidatePunctuated) {
      return candidatePunctuated;
    }
    if (existingBodyStyle !== candidateBodyStyle) {
      return !candidateBodyStyle;
    }
    if (
      existing.kind === "table" &&
      candidate.kind === "table" &&
      existing.source === candidate.source &&
      Number(candidate.page) > Number(existing.page) &&
      existingTopCaption &&
      !existingBodyStyle &&
      !existingContinued
    ) {
      return false;
    }
    if (!existingTail && candidateTail && (!existingOrder || !candidateOrder || candidateOrder >= existingOrder)) {
      return true;
    }
    if (existingTail && !candidateTail) {
      return false;
    }
    if (existing.source !== candidate.source) {
      if (existing.source === "main" && candidate.source !== "main") {
        return candidateScore > existingScore + 8;
      }
      if (candidate.source === "main" && existing.source !== "main") {
        return candidateScore + 8 >= existingScore;
      }
    }
    if (
      existing.kind === "table" &&
      candidate.kind === "table" &&
      existing.source === candidate.source &&
      existingBodyStyle &&
      candidateBodyStyle &&
      candidateOrder > existingOrder &&
      candidateTail.length >= existingTail.length &&
      candidateScore + 2 >= existingScore
    ) {
      return true;
    }
    if (candidateOrder && existingOrder && candidateOrder !== existingOrder) {
      if (candidateOrder > existingOrder && candidateScore <= existingScore + 12) {
        return false;
      }
      if (candidateOrder < existingOrder && candidateScore + 3 >= existingScore) {
        return true;
      }
    }
    if (Math.abs(candidateScore - existingScore) >= 1) {
      return candidateScore > existingScore;
    }
    const existingHeight = Number.isFinite(existing.avgHeight) ? existing.avgHeight : 0;
    const candidateHeight = Number.isFinite(candidate.avgHeight) ? candidate.avgHeight : 0;
    if (Math.abs(candidateHeight - existingHeight) >= 0.5) {
      return candidateHeight > existingHeight;
    }
    const existingLength = (existing.text || "").length;
    const candidateLength = (candidate.text || "").length;
    if (candidateLength !== existingLength) {
      return candidateLength > existingLength;
    }
    const existingArea = Math.max(0, existing.width || 0) * Math.max(0, existing.height || 0);
    const candidateArea = Math.max(0, candidate.width || 0) * Math.max(0, candidate.height || 0);
    return candidateArea > existingArea;
  }

  function scoreCaptionEntry(entry) {
    const text = normalizeCaptionText(entry && entry.text);
    const avgHeight = Number.isFinite(entry && entry.avgHeight) ? entry.avgHeight : 0;
    const length = text.length;
    const wordCount = text ? text.split(/\s+/).filter(Boolean).length : 0;
    const pageHeight = Number.isFinite(entry && entry.pageHeight) ? entry.pageHeight : 0;
    const top = Number.isFinite(entry && entry.top) ? entry.top : Infinity;
    let score = avgHeight * 8;

    if (isCaptionStart(text)) {
      score += 10;
    }

    if (isBodyStyleCaptionText(text)) {
      score -= 24;
    }

    if (isContinuedCaptionText(text)) {
      score -= 28;
    }

    if (pageHeight > 0 && top <= Math.max(pageHeight * 0.2, 140)) {
      score += 8;
    }

    if (length >= 12 && length <= 180) {
      score += 8;
    } else if (length > 180) {
      score -= Math.min(24, (length - 180) / 5);
    }

    if (wordCount > 28) {
      score -= Math.min(18, (wordCount - 28) * 0.8);
    }

    if (/\b(?:note|notes|footnote|footnotes|source|sources|appendix note)\b/i.test(text)) {
      score -= 18;
    }

    if (/\b(?:standard errors?|robust standard errors?|clustered standard errors?|p-?values?|t-?statistics?|z-?statistics?|significance|confidence intervals?|in parentheses|in brackets|reported in parentheses|reported in brackets)\b/i.test(text)) {
      score -= 16;
    }

    if (/\b(?:observations|coefficients?|controls|fixed effects|first-stage|second-stage|panel [a-z0-9]|sample (?:is|are|includes?)|dependent variable|independent variable)\b/i.test(text)) {
      score -= 8;
    }

    if (/[:;]\s*(?:note|notes|source)\b/i.test(text)) {
      score -= 10;
    }

    return score;
  }

  function addCaptionEntries(tables, lines, meta) {
    for (const candidate of getCaptionCandidates(lines)) {
      const target = getCaptionTarget(candidate.text, {
        allowBodyStyleLead: meta.source !== "main" || (Number.isFinite(candidate.bounds.top) && Number.isFinite(meta.pageHeight) && candidate.bounds.top <= Math.max(meta.pageHeight * 0.2, 140))
      });
      if (!target || !target.key) {
        continue;
      }
      if (hasNearbyCaptionConflict(candidate.text, target)) {
        continue;
      }
      const contentEvidence = getCaptionContentEvidence(candidate, lines, meta, target.kind);
      if (!contentEvidence.plausible) {
        continue;
      }
      const entry = {
        key: target.key,
        kind: target.kind,
        label: target.label,
        source: meta.source,
        page: meta.page,
        text: candidate.text,
        top: candidate.bounds.top,
        left: candidate.bounds.left,
        width: candidate.bounds.width,
        height: candidate.bounds.height,
        focusTop: Number.isFinite(contentEvidence.focusTop) ? contentEvidence.focusTop : candidate.bounds.top,
        avgHeight: candidate.avgHeight || 0,
        pageWidth: meta.pageWidth,
        pageHeight: meta.pageHeight,
        pageRotation: meta.pageRotation || 0
      };
      entry.score = scoreCaptionEntry(entry);
      if (meta.attachmentId) {
        entry.attachmentId = meta.attachmentId;
      }
      if (meta.attachmentName) {
        entry.attachmentName = meta.attachmentName;
      }
      const existing = tables.get(target.key);
      if (shouldReplaceTable(existing, entry)) {
        tables.set(target.key, entry);
      }
    }
  }

  function makeTarget(kind, id) {
    const normalized = normalizeId(id);
    if (!normalized) {
      return null;
    }
    const labels = {
      table: "Table ",
      figure: "Figure ",
      appendix: "Appendix "
    };
    return {
      kind,
      id,
      key: kind === "table" ? normalized : kind + ":" + normalized,
      label: (labels[kind] || "") + id
    };
  }

  function hasNearbyCaptionConflict(text, target) {
    const matches = getRefMatches(text);
    if (matches.length < 2) {
      return false;
    }
    const first = matches[0];
    if (!first || first.key !== target.key || first.kind !== target.kind || first.start > 4) {
      return true;
    }
    const earlyBoundary = Math.max(first.end + 36, 48);
    for (let index = 1; index < matches.length; index++) {
      const match = matches[index];
      if (!match || match.key === first.key) {
        continue;
      }
      if (match.start < earlyBoundary) {
        return true;
      }
    }
    return false;
  }

  function getCaptionTarget(text, options) {
    const value = normalizeCaptionText(text);
    const allowBodyStyleLead = !!(options && options.allowBodyStyleLead);
    const latin = CAPTION_RE.exec(value);
    if (latin && isLikelyCaptionTail(latin[2] || "", { allowBodyStyleLead })) {
      return makeTarget("table", latin[1]);
    }
    const figure = FIGURE_CAPTION_RE.exec(value);
    if (figure && isLikelyCaptionTail(figure[2] || "", { allowBodyStyleLead })) {
      return makeTarget("figure", figure[1]);
    }
    const appendix = APPENDIX_CAPTION_RE.exec(value);
    if (appendix && isLikelyCaptionTail(appendix[2] || "", { allowBodyStyleLead: false })) {
      return makeTarget("appendix", appendix[1]);
    }
    const zh = CAPTION_ZH_RE.exec(value);
    return zh && isLikelyCaptionTail(zh[2] || "", { allowBodyStyleLead }) ? makeTarget("table", zh[1]) : null;
  }

  function isLikelyCaptionTail(tail, options) {
    const allowBodyStyleLead = !!(options && options.allowBodyStyleLead);
    const value = tail.replace(/\s+/g, " ").trim();
    if (!value) {
      return true;
    }
    if (hasCaptionLeadPunctuation(value) && /^[.:\-\u2013\u2014]?\s*(?:reports?|shows?|presents?|summari[sz]es?|lists?|contains?|provides?|documents?|describes?|compares?|indicates?|suggests?|reveals?|demonstrates?|includes?|estimates?|examines?|uses?|displays?|gives?|plots?|depicts?|illustrates?|graphs?|visuali[sz]es?|traces?)\b/i.test(value)) {
      return true;
    }
    if (/^[,;]\s*(?:panel|column|appendix|section)\s+[a-z0-9]+(?:\s*[,;:]\s*|\s+)(?:we|our|this|these|the|results?|find|show|document|estimate|examine|compare|measure|use|present|continue)\b/i.test(value)) {
      return false;
    }
    if (/^[,;]\s*(?:we|our|this|these)\s+(?:find|show|document|estimate|examine|compare|measure|use|present|continue)\b/i.test(value)) {
      return false;
    }
    if (PROSE_TABLE_TAIL_RE.test(value) || PROSE_TABLE_SENTENCE_RE.test(value)) {
      return false;
    }
    if (/^[,;]?\s*(?:and|or|but|because|whereas|while|although|if|when|for|from|in|of|with|on|to)\b/i.test(value)) {
      return false;
    }
    if (/^[,;]?\s*panel\s+[a-z0-9]+\s+(?:also\s+)?(?:reports?|shows?|presents?|contains?|provides?)\b/i.test(value)) {
      return false;
    }
    return true;
  }

  function countWideTextGaps(items, avgHeight) {
    if (!Array.isArray(items) || items.length < 2) {
      return 0;
    }
    const threshold = Math.max(14, (Number(avgHeight) || 0) * 1.8);
    let count = 0;
    for (let index = 1; index < items.length; index++) {
      const previous = items[index - 1];
      const current = items[index];
      const gap = current.left - (previous.left + previous.width);
      if (gap > threshold) {
        count++;
      }
    }
    return count;
  }

  function countNumericTokens(text) {
    const matches = String(text || "").match(/(?:^|[\s(])[-+]?(?:\d+(?:[.,]\d+)*|\.\d+)(?:[%)]|\b)/g);
    return matches ? matches.length : 0;
  }

  function isParagraphLikeLayoutLine(line, pageWidth) {
    if (!line || !line.text || !(pageWidth > 0)) {
      return false;
    }
    const text = String(line.text || "").replace(/\s+/g, " ").trim();
    const tokenCount = text ? text.split(/\s+/).filter(Boolean).length : 0;
    const widthRatio = line.bounds && Number.isFinite(line.bounds.width) ? line.bounds.width / pageWidth : 0;
    if (tokenCount < 8 || widthRatio < 0.45) {
      return false;
    }
    if (!/[a-z]{3,}/i.test(text)) {
      return false;
    }
    if (countWideTextGaps(line.items, line.avgHeight) > 0) {
      return false;
    }
    if (/^(?:note|notes|source|sources|continued)\b/i.test(text)) {
      return false;
    }
    if (/^[A-Z0-9][A-Z0-9\s,.;:%()\/-]{0,48}$/.test(text)) {
      return false;
    }
    return true;
  }

  function isTabularLikeLayoutLine(line, pageWidth) {
    if (!line || !line.text || !(pageWidth > 0)) {
      return false;
    }
    const text = String(line.text || "").replace(/\s+/g, " ").trim();
    const tokenCount = text ? text.split(/\s+/).filter(Boolean).length : 0;
    const widthRatio = line.bounds && Number.isFinite(line.bounds.width) ? line.bounds.width / pageWidth : 0;
    const wideGapCount = countWideTextGaps(line.items, line.avgHeight);
    const numericTokens = countNumericTokens(text);
    if (wideGapCount >= 2) {
      return true;
    }
    if (wideGapCount >= 1 && (numericTokens >= 2 || tokenCount <= 14 || widthRatio < 0.78)) {
      return true;
    }
    if (numericTokens >= 3 && widthRatio < 0.68) {
      return true;
    }
    return false;
  }

  function getCaptionContentEvidence(candidate, lines, meta, kind) {
    const pageWidth = Number(meta && meta.pageWidth) || 0;
    const pageHeight = Number(meta && meta.pageHeight) || 0;
    const candidateTop = candidate && candidate.bounds && Number.isFinite(candidate.bounds.top) ? candidate.bounds.top : 0;
    const candidateHeight = candidate && candidate.bounds && Number.isFinite(candidate.bounds.height)
      ? candidate.bounds.height
      : Number(candidate && candidate.avgHeight) || 0;
    const candidateBottom = candidateTop + candidateHeight;
    const focusFallback = candidateBottom + Math.max(18, (Number(candidate && candidate.avgHeight) || 0) * 1.2);

    if (kind === "appendix") {
      return {
        plausible: true,
        focusTop: candidateTop
      };
    }

    const following = [];
    const searchLimit = pageHeight > 0
      ? Math.min(pageHeight, candidateBottom + Math.max(pageHeight * 0.32, 220))
      : candidateBottom + 260;
    for (let index = Number(candidate && candidate.endIndex) + 1; index < lines.length; index++) {
      const line = lines[index];
      if (!line || !line.text || !line.bounds) {
        continue;
      }
      if (line.bounds.top + line.bounds.height <= candidateBottom - Math.max(4, (Number(candidate && candidate.avgHeight) || 0) * 0.3)) {
        continue;
      }
      if (isCaptionStart(line.text) && line.bounds.top >= candidateBottom + Math.max(10, (Number(candidate && candidate.avgHeight) || 0) * 0.8)) {
        break;
      }
      if (line.bounds.top > searchLimit) {
        break;
      }
      following.push(line);
      if (following.length >= 12) {
        break;
      }
    }

    if (!following.length) {
      return {
        plausible: pageHeight > 0 ? candidateBottom >= pageHeight * 0.72 : kind === "figure",
        focusTop: focusFallback
      };
    }

    let earlyParagraphCount = 0;
    let paragraphRun = 0;
    let maxParagraphRun = 0;
    let firstTabularTop = NaN;
    let firstNonParagraphTop = NaN;
    for (let index = 0; index < following.length; index++) {
      const line = following[index];
      const paragraphLike = isParagraphLikeLayoutLine(line, pageWidth);
      const tabularLike = isTabularLikeLayoutLine(line, pageWidth);
      if (tabularLike && !Number.isFinite(firstTabularTop)) {
        firstTabularTop = line.bounds.top;
      }
      if (!paragraphLike && !Number.isFinite(firstNonParagraphTop)) {
        firstNonParagraphTop = line.bounds.top;
      }
      if (paragraphLike) {
        paragraphRun++;
        if (index < 4) {
          earlyParagraphCount++;
        }
      } else {
        paragraphRun = 0;
      }
      maxParagraphRun = Math.max(maxParagraphRun, paragraphRun);
    }

    if (Number.isFinite(firstTabularTop)) {
      return {
        plausible: true,
        focusTop: firstTabularTop
      };
    }

    if (earlyParagraphCount >= 2 || maxParagraphRun >= 3) {
      return {
        plausible: false,
        focusTop: candidateTop
      };
    }

    return {
      plausible: true,
      focusTop: Number.isFinite(firstNonParagraphTop) ? firstNonParagraphTop : following[0].bounds.top
    };
  }

  async function buildIndex() {
    const { api } = await ensureCurrentDocument();
    if (state.index) {
      return state.index;
    }
    if (state.indexPromise) {
      return state.indexPromise;
    }
    state.indexPromise = (async function () {
      const tables = new Map();
      const pages = new Map();
      state.index = { tables, pages, numPages: 0, complete: false };
      if (!api) {
        state.index.complete = true;
        return state.index;
      }

      await waitForDocumentReady(api);
      const numPages = api.numPages();
      state.index.numPages = numPages;
      for (let pageNumber = 1; pageNumber <= numPages; pageNumber++) {
        try {
          const page = await api.getTextPage(pageNumber);
          const indexPage = getIndexPageData(page);
          if (indexPage) {
            const lines = makeLines(indexPage.items);
            pages.set(pageNumber, { page, lines, indexPage });
            addCaptionEntries(tables, lines, {
              source: "main",
              page: pageNumber,
              pageWidth: indexPage.width,
              pageHeight: indexPage.height,
              pageRotation: indexPage.pageRotation
            });
          }
        } catch (error) {
          console.warn("Google Scholar Reader table preview: text index failed", pageNumber, error);
        }
        await yieldToBrowser();
      }

      if (ENABLE_ATTACHMENT_PREVIEWS) {
        const attachments = await getAttachmentDocs();
        for (const attachment of attachments) {
          for (let pageNumber = 1; pageNumber <= attachment.pdf.numPages; pageNumber++) {
            try {
              const page = await getAttachmentTextPage(attachment, pageNumber);
              const indexPage = getAttachmentIndexPageData(page);
              if (!indexPage) {
                continue;
              }
              const lines = makeLines(indexPage.items);
              addCaptionEntries(tables, lines, {
                source: "attachment",
                attachmentId: attachment.id,
                attachmentName: attachment.name,
                page: pageNumber,
                pageWidth: indexPage.width,
                pageHeight: indexPage.height,
                pageRotation: indexPage.pageRotation
              });
            } catch (error) {
              console.warn("Google Scholar Reader table preview: attachment text index failed", attachment.name, pageNumber, error);
            }
            await yieldToBrowser();
          }
        }
      }

      state.index.complete = true;
      return state.index;
    })();
    return state.indexPromise;
  }

  async function waitForIndexWithTable(key) {
    const indexPromise = buildIndex();
    while (true) {
      const index = state.index;
      if (index && (findTable(index, key) || index.complete)) {
        return index;
      }
      const finished = await Promise.race([
        indexPromise.then(() => true),
        new Promise(resolve => setTimeout(() => resolve(false), 80))
      ]);
      if (finished) {
        return state.index;
      }
    }
  }

  function isSuperscriptSegment(segment, baseline) {
    if (!segment || !segment.rect || !baseline) {
      return false;
    }
    const heightRatio = segment.rect.height / Math.max(1, baseline.height);
    const segmentMid = segment.rect.top + segment.rect.height * 0.5;
    const baselineMid = baseline.top + baseline.height * 0.5;
    return heightRatio <= 0.82 && segmentMid < baselineMid - Math.max(1.5, baseline.height * 0.08);
  }

  function trimSuperscriptFootnoteMatch(line, matchStart, matchEnd, rawId) {
    const text = line && typeof line.text === "string" ? line.text : "";
    const segments = line && Array.isArray(line.segments) ? line.segments : [];
    if (!text || !segments.length || !/^[0-9]+(?:[.-][0-9]{1,3})?[A-Za-z]?$/.test(String(rawId || ""))) {
      return { end: matchEnd, id: rawId };
    }

    const overlapped = segments.filter(segment => segment.end > matchStart && segment.start < matchEnd);
    if (overlapped.length < 2) {
      return { end: matchEnd, id: rawId };
    }

    const baselineSegments = overlapped.filter(segment => /[A-Za-z0-9]/.test(text.slice(segment.start, segment.end)));
    const baseline = baselineSegments
      .filter(segment => !/[0-9]+$/.test(text.slice(segment.start, segment.end).trim()) || segment !== overlapped[overlapped.length - 1])
      .map(segment => segment.rect)
      .sort((first, second) => second.height - first.height)[0];
    if (!baseline) {
      return { end: matchEnd, id: rawId };
    }

    let trimmedEnd = matchEnd;
    for (let index = overlapped.length - 1; index >= 0; index--) {
      const segment = overlapped[index];
      if (!isSuperscriptSegment(segment, baseline)) {
        break;
      }
      trimmedEnd = Math.min(trimmedEnd, segment.start);
    }

    while (trimmedEnd > matchStart && /[.:\-]/.test(text[trimmedEnd - 1])) {
      trimmedEnd--;
    }
    if (trimmedEnd >= matchEnd) {
      return { end: matchEnd, id: rawId };
    }

    const trimmedText = text.slice(matchStart, trimmedEnd);
    REF_RE.lastIndex = 0;
    const trimmedMatch = REF_RE.exec(trimmedText);
    REF_RE.lastIndex = 0;
    if (!trimmedMatch) {
      return { end: matchEnd, id: rawId };
    }
    const trimmedId = trimmedMatch[1] || trimmedMatch[2] || trimmedMatch[3] || trimmedMatch[4] || rawId;
    return { end: trimmedEnd, id: trimmedId };
  }

  function getRefMatches(lineOrText) {
    const line = typeof lineOrText === "string" ? null : lineOrText;
    const text = typeof lineOrText === "string" ? lineOrText : String(lineOrText && lineOrText.text || "");
    const matches = [];
    REF_RE.lastIndex = 0;
    let match;
    while ((match = REF_RE.exec(text))) {
      let tableId = match[1] || match[4];
      let figureId = match[2];
      let appendixId = match[3];
      let matchEnd = match.index + match[0].length;
      if (line) {
        const trimmed = trimSuperscriptFootnoteMatch(line, match.index, matchEnd, tableId || figureId || appendixId);
        matchEnd = trimmed.end;
        if (tableId) {
          tableId = trimmed.id;
        } else if (figureId) {
          figureId = trimmed.id;
        } else if (appendixId) {
          appendixId = trimmed.id;
        }
      }
      const target = tableId ? makeTarget("table", tableId) :
        figureId ? makeTarget("figure", figureId) :
        appendixId ? makeTarget("appendix", appendixId) : null;
      if (!target) {
        continue;
      }
      matches.push({
        key: target.key,
        id: target.id,
        kind: target.kind,
        label: target.label,
        start: match.index,
        end: matchEnd
      });
    }
    REF_RE.lastIndex = 0;
    return matches;
  }

  function mergeClientRects(rects) {
    let left = Infinity;
    let top = Infinity;
    let right = -Infinity;
    let bottom = -Infinity;
    for (const rect of rects) {
      if (!rect || !rect.width || !rect.height) {
        continue;
      }
      left = Math.min(left, rect.left);
      top = Math.min(top, rect.top);
      right = Math.max(right, rect.right);
      bottom = Math.max(bottom, rect.bottom);
    }
    if (!Number.isFinite(left) || !Number.isFinite(top) || !Number.isFinite(right) || !Number.isFinite(bottom)) {
      return null;
    }
    return {
      left,
      top,
      right,
      bottom,
      width: Math.max(0, right - left),
      height: Math.max(0, bottom - top)
    };
  }

  function buildTextLayerLines(textLayer) {
    const lines = [];
    let current = [];
    let previousRect = null;
    let previousEndedLine = false;
    for (const span of textLayer.querySelectorAll(".gsr-text:not(.gsr-hide)")) {
      const text = span.textContent || "";
      if (!text) {
        continue;
      }
      const rect = span.getBoundingClientRect();
      if (!rect.width || !rect.height) {
        continue;
      }
      const tolerance = previousRect ? Math.max(2, Math.min(8, Math.max(previousRect.height, rect.height) * 0.7)) : 0;
      const startsNewLine = previousEndedLine || (previousRect && Math.abs(rect.top - previousRect.top) > tolerance);
      if (startsNewLine && current.length) {
        lines.push(current);
        current = [];
      }
      current.push({
        span,
        node: span.firstChild && span.firstChild.nodeType === Node.TEXT_NODE ? span.firstChild : null,
        text,
        rect
      });
      previousRect = rect;
      previousEndedLine = span.getAttribute("data-eol") === "1";
    }
    if (current.length) {
      lines.push(current);
    }

    return lines.map(spans => {
      const segments = [];
      let text = "";
      for (const segment of spans) {
        const start = text.length;
        text += segment.text;
        const end = text.length;
        if (end <= start) {
          continue;
        }
        segments.push({
          span: segment.span,
          node: segment.node,
          rect: segment.rect,
          start,
          end
        });
      }
      return segments.length ? { text, segments } : null;
    }).filter(Boolean);
  }

  function getMatchRect(line, match) {
    const segments = line && Array.isArray(line.segments) ? line.segments : [];
    const overlapped = segments.filter(segment => segment.end > match.start && segment.start < match.end);
    if (!overlapped.length) {
      return null;
    }

    const first = overlapped[0];
    const last = overlapped[overlapped.length - 1];
    if (first.node && last.node) {
      const range = document.createRange();
      const startOffset = Math.max(0, Math.min(first.node.length, match.start - first.start));
      const endOffset = Math.max(0, Math.min(last.node.length, match.end - last.start));
      range.setStart(first.node, startOffset);
      range.setEnd(last.node, first === last ? Math.max(startOffset, endOffset) : endOffset);
      const rect = mergeClientRects(Array.from(range.getClientRects()));
      range.detach();
      if (rect) {
        return rect;
      }
    }
    return mergeClientRects(overlapped.map(segment => segment.rect));
  }

  function ensureLayer(page) {
    let layer = page.querySelector(":scope > .gsr-table-ref-layer");
    if (!layer) {
      layer = document.createElement("div");
      layer.className = "gsr-table-ref-layer";
      page.appendChild(layer);
    } else if (layer.parentElement === page && page.lastElementChild !== layer) {
      page.appendChild(layer);
    }
    return layer;
  }

  function rectsOverlap(first, second) {
    return !!first && !!second && first.left < second.right && first.right > second.left && first.top < second.bottom && first.bottom > second.top;
  }

  function hasOverlayConflict(page, rect) {
    if (!page || !rect) {
      return false;
    }
    for (const element of page.querySelectorAll(".gsr-citation-link, .gsr-reference-link, .gsr-author-ref")) {
      const elementRect = element.getBoundingClientRect();
      if (rectsOverlap(rect, elementRect)) {
        return true;
      }
    }
    return false;
  }

  function consumeRefEvent(event) {
    event.preventDefault();
    event.stopPropagation();
    if (typeof event.stopImmediatePropagation === "function") {
      event.stopImmediatePropagation();
    }
  }

  function observeLayoutElement(element) {
    if (!state.resizeObserver || !element || state.observedElements.has(element)) {
      return;
    }
    state.observedElements.add(element);
    state.resizeObserver.observe(element);
  }

  function observePageLayout(page) {
    observeLayoutElement(page);
    observeLayoutElement(page.querySelector(".gsr-text-ctn"));
  }

  function shouldIgnoreAnnotateMutation(mutation) {
    const target = mutation && mutation.target;
    if (!(target instanceof Element)) {
      return false;
    }
    if (target.closest(".gsr-table-ref-layer, .gsr-table-preview, .gsr-table-mode-tools, .gsr-finder, .gsr-find-map")) {
      return true;
    }
    const textLayer = target.closest(".gsr-text-ctn");
    if (!textLayer) {
      return false;
    }
    if (mutation.type === "attributes") {
      return target !== textLayer;
    }
    if (mutation.type === "childList") {
      return target !== textLayer;
    }
    return false;
  }

  function rectSizeSignature(rect) {
    return [
      Math.round(rect.width * 10),
      Math.round(rect.height * 10)
    ].join(",");
  }

  function textLayerLayoutSignature(page, textLayer, pageRect) {
    const spans = textLayer.children;
    const spanCount = spans ? spans.length : 0;
    const sampleIndexes = spanCount ? [0, Math.floor((spanCount - 1) / 2), spanCount - 1] : [];
    const samples = sampleIndexes.map(index => {
      const span = spans[index];
      if (!span) {
        return "";
      }
      return [
        span.getAttribute("style") || "",
        rectSizeSignature(span.getBoundingClientRect())
      ].join("@");
    });
    return [
      page.clientWidth,
      page.clientHeight,
      rectSizeSignature(pageRect),
      textLayer.getAttribute("style") || "",
      ...samples
    ].join(":");
  }

  function updateRefButton(button, label) {
    const action = state.mode === MODE_JUMP ? "Jump to " : "Preview ";
    button.setAttribute("aria-label", action + label);
    button.title = action + label;
  }

  function updateRefModes() {
    for (const button of document.querySelectorAll(".gsr-table-ref")) {
      updateRefButton(button, button.dataset.tableLabel || "table");
    }
  }

  function annotatePage(page, pageRect) {
    const textLayer = page.querySelector(".gsr-text-ctn");
    if (!textLayer) {
      return;
    }
    const layer = ensureLayer(page);
    const currentPageRect = pageRect || page.getBoundingClientRect();
    const signature = [
      textLayer.childElementCount,
      textLayerLayoutSignature(page, textLayer, currentPageRect)
    ].join(":");
    if (layer.dataset.signature === signature) {
      return;
    }
    layer.dataset.signature = signature;
    layer.textContent = "";
    for (const line of buildTextLayerLines(textLayer)) {
      const matches = getRefMatches(line);
      for (const match of matches) {
        const rect = getMatchRect(line, match);
        if (!rect.width || !rect.height) {
          continue;
        }
        if (hasOverlayConflict(page, rect)) {
          continue;
        }
        const button = document.createElement("button");
        button.type = "button";
        button.className = "gsr-table-ref";
        button.dataset.tableKey = match.key;
        button.dataset.tableLabel = match.label;
        updateRefButton(button, match.label);
        button.style.left = rect.left - currentPageRect.left + "px";
        button.style.top = rect.top - currentPageRect.top + "px";
        button.style.width = Math.max(18, rect.width) + "px";
        button.style.height = Math.max(14, rect.height) + "px";
        button.addEventListener("pointerdown", consumeRefEvent, true);
        button.addEventListener("mousedown", consumeRefEvent, true);
        button.addEventListener("mouseup", consumeRefEvent, true);
        button.addEventListener("dblclick", consumeRefEvent, true);
        button.addEventListener("pointerenter", event => {
          if (state.mode !== MODE_PREVIEW) {
            return;
          }
          clearHideTimer();
          showPreview(match.key, match.label, event.currentTarget, false);
        });
        button.addEventListener("focus", event => {
          if (state.mode !== MODE_PREVIEW) {
            return;
          }
          clearHideTimer();
          showPreview(match.key, match.label, event.currentTarget, false);
        });
        button.addEventListener("pointerleave", scheduleHide);
        button.addEventListener("click", event => {
          event.preventDefault();
          event.stopPropagation();
          if (state.mode === MODE_JUMP) {
            jumpToTable(match.key, match.label, event.currentTarget);
          } else {
            closePreview();
            showPreview(match.key, match.label, event.currentTarget, true);
          }
        });
        layer.appendChild(button);
      }
    }
  }

  function isPageNearViewport(pageRect) {
    return !!pageRect && pageRect.bottom >= -ANNOTATE_VIEWPORT_MARGIN && pageRect.top <= window.innerHeight + ANNOTATE_VIEWPORT_MARGIN;
  }

  function annotateRenderedRefs() {
    for (const page of document.querySelectorAll(".gsr-page")) {
      observePageLayout(page);
      const pageRect = page.getBoundingClientRect();
      if (!isPageNearViewport(pageRect)) {
        continue;
      }
      annotatePage(page, pageRect);
    }
  }

  function scheduleAnnotate() {
    if (state.scheduled) {
      return;
    }
    state.scheduled = true;
    const run = function () {
      if (!state.scheduled) {
        return;
      }
      state.scheduled = false;
      installToolbar();
      annotateRenderedRefs();
      updateRefModes();
    };
    requestAnimationFrame(run);
    setTimeout(run, 100);
  }

  function scheduleIndexBuild(delay) {
    if (state.index || state.indexPromise) {
      return;
    }
    if (state.indexBuildTimer) {
      clearTimeout(state.indexBuildTimer);
    }
    state.indexBuildTimer = setTimeout(function () {
      state.indexBuildTimer = 0;
      const run = function () {
        if (state.index || state.indexPromise) {
          return;
        }
        buildIndex().catch(error => {
          console.warn("Google Scholar Reader table preview: index failed", error);
        });
      };
      if (typeof window.requestIdleCallback === "function") {
        window.requestIdleCallback(run, { timeout: 1500 });
      } else {
        run();
      }
    }, Math.max(0, Number(delay) || 0));
  }

  function clearHideTimer() {
    if (state.hideTimer) {
      clearTimeout(state.hideTimer);
      state.hideTimer = 0;
    }
  }

  function scheduleHide() {
    clearHideTimer();
    if (!state.preview) {
      return;
    }
    state.hideTimer = setTimeout(function () {
      closePreview(state.preview);
    }, 250);
  }

  function releaseHeldPage() {
    if (state.heldPage && state.api) {
      try {
        state.api.releasePage(state.heldPage);
      } catch (error) {
        console.warn("Google Scholar Reader table preview: release failed", error);
      }
    }
    state.heldPage = 0;
  }

  function bringPreviewToFront(preview) {
    if (!preview || !preview.panel) {
      return;
    }
    preview.panel.style.zIndex = String(++state.previewZ);
  }

  function promotePreviewToPinned(preview) {
    if (!preview || preview.pinned) {
      return;
    }
    clearHideTimer();
    preview.pinned = true;
    preview.panel.classList.add("gsr-pinned");
    state.previewWindows.add(preview);
    if (state.preview === preview) {
      state.preview = null;
    }
  }

  function clampPreviewPosition(panel, left, top) {
    const panelRect = panel.getBoundingClientRect();
    return {
      left: clamp(left, 12, Math.max(12, window.innerWidth - panelRect.width - 12)),
      top: clamp(top, 12, Math.max(12, window.innerHeight - panelRect.height - 12))
    };
  }

  function clampPreviewSize(width, height) {
    const maxWidth = Math.max(280, window.innerWidth - 24);
    const maxHeight = Math.max(180, window.innerHeight - 24);
    return {
      width: clamp(width, Math.min(MIN_PREVIEW_WIDTH, maxWidth), maxWidth),
      height: clamp(height, Math.min(MIN_PREVIEW_HEIGHT, maxHeight), maxHeight)
    };
  }

  function setPreviewUserSized(preview, enabled) {
    if (!preview) {
      return;
    }
    preview.userSized = !!enabled;
    preview.panel.classList.toggle("gsr-user-sized", !!enabled);
  }

  function normalizeRotationDegrees(rotation) {
    return ((Number(rotation) || 0) % 360 + 360) % 360;
  }

  function updatePreviewRotateButton(preview) {
    if (!preview || !preview.rotate) {
      return;
    }
    const hasTable = !!preview.currentTable;
    preview.rotate.disabled = !hasTable;
    preview.rotate.title = hasTable ? "Rotate 90 degrees clockwise" : "Rotate preview";
    preview.rotate.setAttribute("aria-label", hasTable ? "Rotate table preview clockwise" : "Rotate table preview");
  }

  function resetPreviewRenderState(preview) {
    if (!preview) {
      return;
    }
    preview.currentTable = null;
    preview.manualRotation = 0;
    updatePreviewRotateButton(preview);
  }

  function syncPreviewContentLayout(preview) {
    if (!preview || !preview.content || !preview.canvas) {
      return;
    }
    const bodyWidth = preview.body.clientWidth;
    const bodyHeight = preview.body.clientHeight;
    if (!bodyWidth || !bodyHeight || !preview.canvas.width || !preview.canvas.height) {
      return;
    }
    const aspectRatio = preview.canvas.width / preview.canvas.height;
    const captionHeight = preview.caption ? preview.caption.offsetHeight + 12 : 0;
    const inlinePadding = clamp(bodyWidth * 0.08, 24, 80);
    const baseWidth = Math.max(220, Math.round(bodyWidth - inlinePadding * 2));
    const availablePageHeight = Math.max(180, Math.round(bodyHeight - captionHeight - 12));
    const allowOverflow = preview.userSized || preview.panel.classList.contains("gsr-fullscreen");
    const maxWidth = allowOverflow ? Number.POSITIVE_INFINITY : Math.max(220, bodyWidth - 16);
    const contentWidth = Math.min(maxWidth, Math.max(baseWidth, Math.round(availablePageHeight * aspectRatio)));
    preview.content.style.width = contentWidth + "px";
  }

  function syncAllPreviewLayouts() {
    if (state.preview) {
      syncPreviewContentLayout(state.preview);
    }
    for (const preview of state.previewWindows) {
      syncPreviewContentLayout(preview);
    }
  }

  function applyPreviewSize(preview, width, height) {
    if (!preview) {
      return;
    }
    const size = clampPreviewSize(width, height);
    preview.panel.style.width = size.width + "px";
    preview.panel.style.height = size.height + "px";
    preview.panel.style.maxHeight = "none";
    setPreviewUserSized(preview, true);
    const rect = preview.panel.getBoundingClientRect();
    const position = clampPreviewPosition(preview.panel, rect.left, rect.top);
    preview.panel.style.left = position.left + "px";
    preview.panel.style.top = position.top + "px";
    syncPreviewContentLayout(preview);
  }

  function setPreviewFullscreen(preview, enabled) {
    if (!preview) {
      return;
    }
    if (enabled) {
      preview.restoreRect = {
        left: preview.panel.style.left,
        top: preview.panel.style.top,
        width: preview.panel.style.width,
        height: preview.panel.style.height,
        maxHeight: preview.panel.style.maxHeight
      };
      preview.panel.style.width = "";
      preview.panel.style.height = "";
      preview.panel.style.maxHeight = "";
    } else if (preview.restoreRect) {
      preview.panel.style.left = preview.restoreRect.left;
      preview.panel.style.top = preview.restoreRect.top;
      preview.panel.style.width = preview.restoreRect.width;
      preview.panel.style.height = preview.restoreRect.height;
      preview.panel.style.maxHeight = preview.restoreRect.maxHeight;
    }
    preview.panel.classList.toggle("gsr-fullscreen", enabled);
    preview.fullscreen.setAttribute("aria-pressed", enabled ? "true" : "false");
    preview.fullscreen.title = enabled ? "Exit full screen" : "Full screen";
    preview.fullscreen.setAttribute("aria-label", enabled ? "Exit full screen table preview" : "Full screen table preview");
    bringPreviewToFront(preview);
    requestAnimationFrame(function () {
      syncPreviewContentLayout(preview);
    });
  }

  function togglePreviewFullscreen(preview) {
    if (!preview) {
      return;
    }
    setPreviewFullscreen(preview, !preview.panel.classList.contains("gsr-fullscreen"));
  }

  function closePreview(preview) {
    const target = preview || state.preview;
    if (!target) {
      return;
    }
    if (target === state.preview) {
      clearHideTimer();
    }
    target.token++;
    target.panel.classList.remove("gsr-vis", "gsr-pinned", "gsr-fullscreen", "gsr-dragging");
    setPreviewFullscreen(target, false);
    target.body.textContent = "";
    target.pinned = false;
    target.userMoved = false;
    setPreviewUserSized(target, false);
    target.restoreRect = null;
    target.content = null;
    target.canvas = null;
    target.caption = null;
    resetPreviewRenderState(target);
    if (target === state.preview) {
      return;
    }
    state.previewWindows.delete(target);
    target.panel.remove();
  }

  function closeAllPreviews() {
    if (state.preview) {
      closePreview(state.preview);
    }
    for (const preview of Array.from(state.previewWindows)) {
      closePreview(preview);
    }
  }

  function startPreviewDrag(preview, event) {
    if (!preview || preview.panel.classList.contains("gsr-fullscreen")) {
      return;
    }
    const target = event.target;
    if (!(target instanceof Element) || target.closest(".gsr-table-preview-action, .gsr-table-preview-resize-handle")) {
      return;
    }
    event.preventDefault();
    promotePreviewToPinned(preview);
    preview.userMoved = true;
    preview.panel.classList.add("gsr-dragging");
    bringPreviewToFront(preview);

    const rect = preview.panel.getBoundingClientRect();
    const offsetX = event.clientX - rect.left;
    const offsetY = event.clientY - rect.top;

    const move = function (moveEvent) {
      const position = clampPreviewPosition(preview.panel, moveEvent.clientX - offsetX, moveEvent.clientY - offsetY);
      preview.panel.style.left = position.left + "px";
      preview.panel.style.top = position.top + "px";
    };

    const stop = function () {
      preview.panel.classList.remove("gsr-dragging");
      document.removeEventListener("pointermove", move);
      document.removeEventListener("pointerup", stop);
      document.removeEventListener("pointercancel", stop);
    };

    document.addEventListener("pointermove", move);
    document.addEventListener("pointerup", stop);
    document.addEventListener("pointercancel", stop);
  }

  function startPreviewResize(preview, event, mode) {
    if (!preview || preview.panel.classList.contains("gsr-fullscreen")) {
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    promotePreviewToPinned(preview);
    preview.userMoved = true;
    bringPreviewToFront(preview);
    preview.panel.classList.add("gsr-resizing");

    const rect = preview.panel.getBoundingClientRect();
    const startWidth = rect.width;
    const startHeight = rect.height;
    const startLeft = rect.left;
    const startTop = rect.top;
    const startX = event.clientX;
    const startY = event.clientY;

    const move = function (moveEvent) {
      const nextWidth = mode === "south" ? startWidth : startWidth + (moveEvent.clientX - startX);
      const nextHeight = mode === "east" ? startHeight : startHeight + (moveEvent.clientY - startY);
      const size = clampPreviewSize(nextWidth, nextHeight);
      preview.panel.style.width = size.width + "px";
      preview.panel.style.height = size.height + "px";
      preview.panel.style.maxHeight = "none";
      setPreviewUserSized(preview, true);
      const position = clampPreviewPosition(preview.panel, startLeft, startTop);
      preview.panel.style.left = position.left + "px";
      preview.panel.style.top = position.top + "px";
      syncPreviewContentLayout(preview);
    };

    const stop = function () {
      preview.panel.classList.remove("gsr-resizing");
      document.removeEventListener("pointermove", move);
      document.removeEventListener("pointerup", stop);
      document.removeEventListener("pointercancel", stop);
    };

    document.addEventListener("pointermove", move);
    document.addEventListener("pointerup", stop);
    document.addEventListener("pointercancel", stop);
  }

  function createPreview(pinned) {
    const panel = document.createElement("div");
    panel.className = "gsr-table-preview";
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-label", "Table preview");

    const header = document.createElement("div");
    header.className = "gsr-table-preview-header";
    const title = document.createElement("div");
    title.className = "gsr-table-preview-title";
    const close = document.createElement("button");
    close.type = "button";
    close.className = "gsr-table-preview-action gsr-table-preview-close";
    close.setAttribute("aria-label", "Close table preview");
    close.title = "Close";
    close.innerHTML = '<svg viewBox="0 0 21 21"><path d="M16.6 5.6L15.3 4.3L10.5 9.2L5.6 4.3L4.3 5.6L9.2 10.5L4.3 15.3L5.6 16.6L10.5 11.7L15.3 16.6L16.6 15.3L11.7 10.5L16.6 5.6Z"/></svg>';
    const rotate = document.createElement("button");
    rotate.type = "button";
    rotate.className = "gsr-table-preview-action gsr-table-preview-rotate";
    rotate.setAttribute("aria-label", "Rotate table preview");
    rotate.title = "Rotate preview";
    rotate.disabled = true;
    rotate.innerHTML = '<svg viewBox="0 0 21 21"><path d="M10.5 3A7.5 7.5 0 1 1 3 10.5H4.7A5.8 5.8 0 1 0 6.4 6.4L9 9H3V3L5.2 5.2A7.46 7.46 0 0 1 10.5 3Z"/></svg>';
    const fullscreen = document.createElement("button");
    fullscreen.type = "button";
    fullscreen.className = "gsr-table-preview-action gsr-table-preview-fullscreen";
    fullscreen.setAttribute("aria-label", "Full screen table preview");
    fullscreen.setAttribute("aria-pressed", "false");
    fullscreen.title = "Full screen";
    fullscreen.innerHTML = '<svg viewBox="0 0 21 21"><path d="M4 9V4H9V5.5H6.6L9.6 8.5L8.5 9.6L5.5 6.6V9H4ZM12 4H17V9H15.5V6.6L12.5 9.6L11.4 8.5L14.4 5.5H12V4ZM4 12H5.5V14.4L8.5 11.4L9.6 12.5L6.6 15.5H9V17H4V12ZM15.5 12H17V17H12V15.5H14.4L11.4 12.5L12.5 11.4L15.5 14.4V12Z"/></svg>';
    header.append(title, rotate, fullscreen, close);

    const body = document.createElement("div");
    body.className = "gsr-table-preview-body";
    const resizeHandleEast = document.createElement("div");
    resizeHandleEast.className = "gsr-table-preview-resize-handle gsr-table-preview-resize-east";
    resizeHandleEast.setAttribute("aria-hidden", "true");
    const resizeHandleCorner = document.createElement("div");
    resizeHandleCorner.className = "gsr-table-preview-resize-handle gsr-table-preview-resize-corner";
    resizeHandleCorner.setAttribute("aria-hidden", "true");
    panel.append(header, body, resizeHandleEast, resizeHandleCorner);
    document.body.appendChild(panel);

    const preview = {
      panel,
      title,
      body,
      rotate,
      fullscreen,
      resizeHandleEast,
      resizeHandleCorner,
      pinned: !!pinned,
      token: 0,
      userMoved: false,
      userSized: false,
      content: null,
      canvas: null,
      caption: null,
      currentTable: null,
      manualRotation: 0,
      cascadeOffset: null,
      restoreRect: null
    };

    if (!pinned) {
      panel.addEventListener("pointerenter", clearHideTimer);
      panel.addEventListener("pointerleave", scheduleHide);
    }
    panel.addEventListener("pointerdown", function () {
      bringPreviewToFront(preview);
    });
    panel.addEventListener("pointerdown", function (event) {
      startPreviewDrag(preview, event);
    });
    close.addEventListener("click", event => {
      event.preventDefault();
      closePreview(preview);
    });
    rotate.addEventListener("click", event => {
      event.preventDefault();
      if (!preview.currentTable) {
        return;
      }
      preview.manualRotation = normalizeRotationDegrees(preview.manualRotation + 90);
      const token = ++preview.token;
      renderTable(preview, preview.currentTable, token).catch(error => {
        console.warn("Google Scholar Reader table preview: manual rotation failed", error);
        if (token === preview.token) {
          setPreviewMessage(preview, "Unable to rotate this table preview.");
        }
      });
    });
    fullscreen.addEventListener("click", event => {
      event.preventDefault();
      togglePreviewFullscreen(preview);
    });
    resizeHandleEast.addEventListener("pointerdown", function (event) {
      startPreviewResize(preview, event, "east");
    });
    resizeHandleCorner.addEventListener("pointerdown", function (event) {
      startPreviewResize(preview, event, "corner");
    });

    bringPreviewToFront(preview);
    updatePreviewRotateButton(preview);
    if (pinned) {
      panel.classList.add("gsr-pinned");
      state.previewWindows.add(preview);
      return preview;
    }
    state.preview = preview;
    return preview;
  }

  function ensurePreview() {
    if (state.preview) {
      return state.preview;
    }
    return createPreview(false);
  }

  function createPinnedPreview() {
    return createPreview(true);
  }

  function setPreviewMessage(preview, message) {
    preview.body.textContent = "";
    preview.content = null;
    preview.canvas = null;
    preview.caption = null;
    const status = document.createElement("div");
    status.className = "gsr-table-preview-status";
    status.textContent = message;
    preview.body.appendChild(status);
  }

  function positionPreview(preview, anchor) {
    const panel = preview.panel;
    panel.style.left = "12px";
    panel.style.top = "12px";
    panel.classList.add("gsr-vis");
    bringPreviewToFront(preview);
    if (panel.classList.contains("gsr-fullscreen") || preview.userMoved) {
      return;
    }
    const anchorRect = anchor ? anchor.getBoundingClientRect() : { left: 24, top: 24, bottom: 64 };
    const cascade = preview.pinned
      ? (preview.cascadeOffset == null ? (preview.cascadeOffset = (state.previewCascade++ % 6) * 28) : preview.cascadeOffset)
      : 0;
    let left = anchorRect.left + cascade;
    let top = anchorRect.bottom + 10 + cascade;
    const panelRect = panel.getBoundingClientRect();
    if (top + panelRect.height > window.innerHeight - 12) {
      top = Math.max(12, anchorRect.top - panelRect.height - 10 - cascade);
    }
    const position = clampPreviewPosition(panel, left, top);
    panel.style.left = position.left + "px";
    panel.style.top = position.top + "px";
  }

  function findTable(index, key) {
    if (index.tables.has(key)) {
      return index.tables.get(key);
    }
    if (key.includes(":")) {
      return null;
    }
    const simple = key.replace(/[a-z]$/i, "");
    return simple && index.tables.get(simple) || null;
  }

  function flashRef(anchor, className) {
    anchor.classList.add(className);
    setTimeout(function () {
      anchor.classList.remove(className);
    }, 1200);
  }

  function showJumpMarker(pageElement, ratio) {
    let marker = pageElement.querySelector(":scope > .gsr-table-jump-marker");
    if (!marker) {
      marker = document.createElement("div");
      marker.className = "gsr-table-jump-marker";
      pageElement.appendChild(marker);
    }
    marker.style.top = clamp(ratio * 100, 0, 99) + "%";
    marker.classList.remove("gsr-vis");
    marker.getBoundingClientRect();
    marker.classList.add("gsr-vis");
    clearTimeout(marker._gsrTimer);
    marker._gsrTimer = setTimeout(function () {
      marker.classList.remove("gsr-vis");
    }, 2200);
  }

  function getPageNumberFromElement(pageElement) {
    if (!(pageElement instanceof Element)) {
      return 0;
    }
    const value = Number(
      pageElement.dataset.pn ||
      pageElement.dataset.pageNumber ||
      pageElement.getAttribute("data-pn") ||
      pageElement.getAttribute("data-page-number") ||
      0
    );
    return Number.isFinite(value) && value > 0 ? value : 0;
  }

  function rememberJumpOrigin(anchor) {
    const scrollElement = state.api && typeof state.api.getScrollElement === "function"
      ? state.api.getScrollElement()
      : document.querySelector(".gsr-body");
    if (!scrollElement) {
      return;
    }
    const origin = {
      scrollTop: scrollElement.scrollTop,
      scrollLeft: scrollElement.scrollLeft
    };
    if (anchor instanceof Element) {
      const pageElement = anchor.closest(".gsr-page");
      const pageNumber = getPageNumberFromElement(pageElement);
      if (pageNumber) {
        origin.page = pageNumber;
      }
      const pageHeight = pageElement ? pageElement.offsetHeight : 0;
      const anchorTop = parseFloat(anchor.style.top) || anchor.offsetTop || 0;
      const anchorHeight = parseFloat(anchor.style.height) || anchor.offsetHeight || 0;
      if (pageHeight > 0) {
        origin.ratio = clamp((anchorTop + anchorHeight * 0.5) / pageHeight, 0, 1);
      }
    }
    state.jumpHistory.push(origin);
    if (state.jumpHistory.length > MAX_JUMP_HISTORY) {
      state.jumpHistory.shift();
    }
  }

  async function restoreJumpOrigin() {
    const origin = state.jumpHistory.pop();
    if (!origin) {
      return false;
    }
    clearHideTimer();
    closePreview();
    const { api } = await ensureCurrentDocument();
    if (!api) {
      return false;
    }
    const scrollElement = api.getScrollElement() || document.querySelector(".gsr-body");
    if (!scrollElement) {
      return false;
    }

    let top = Number.isFinite(origin.scrollTop) ? origin.scrollTop : scrollElement.scrollTop;
    const left = Number.isFinite(origin.scrollLeft) ? origin.scrollLeft : scrollElement.scrollLeft;
    if (origin.page) {
      await api.ensurePage(origin.page);
      const pageElement = api.getPageElement(origin.page);
      if (pageElement) {
        const ratio = clamp(Number.isFinite(origin.ratio) ? origin.ratio : 0, 0, 1);
        const offset = Math.min(140, scrollElement.clientHeight * 0.22);
        top = Math.max(0, pageElement.offsetTop + pageElement.offsetHeight * ratio - offset);
      }
    }

    scrollElement.scrollTo({ top, left, behavior: "smooth" });
    return true;
  }

  function handleMouseBackNavigation(event) {
    if (!(event instanceof MouseEvent) || event.button !== 3 || state.mode !== MODE_JUMP || !state.jumpHistory.length) {
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    if (typeof event.stopImmediatePropagation === "function") {
      event.stopImmediatePropagation();
    }
    restoreJumpOrigin().catch(error => {
      console.warn("Google Scholar Reader table preview: unable to restore jump origin", error);
    });
  }

  async function jumpToTable(key, label, anchor) {
    clearHideTimer();
    closePreview();
    const { api } = await ensureCurrentDocument();
    if (!api) {
      flashRef(anchor, "gsr-table-ref-missing");
      return;
    }

    const token = ++state.token;
    const index = await waitForIndexWithTable(key);
    if (token !== state.token) {
      return;
    }
    const table = findTable(index, key);
    if (!table) {
      flashRef(anchor, "gsr-table-ref-missing");
      return;
    }
    if (table.source === "attachment") {
      await showPreview(key, label, anchor, true);
      return;
    }

    rememberJumpOrigin(anchor);
    releaseHeldPage();
    state.heldPage = table.page;
    await api.ensurePage(table.page);
    if (token !== state.token) {
      releaseHeldPage();
      return;
    }

    const pageElement = api.getPageElement(table.page);
    const scrollElement = api.getScrollElement() || document.querySelector(".gsr-body");
    if (!pageElement || !scrollElement) {
      flashRef(anchor, "gsr-table-ref-missing");
      releaseHeldPage();
      return;
    }

    const focusTop = Number.isFinite(table.focusTop) ? table.focusTop : table.top;
    const ratio = clamp(table.pageHeight ? focusTop / table.pageHeight : 0, 0, 1);
    const offset = Math.min(140, scrollElement.clientHeight * 0.22);
    const top = Math.max(0, pageElement.offsetTop + pageElement.offsetHeight * ratio - offset);
    scrollElement.scrollTo({ top, left: scrollElement.scrollLeft, behavior: "smooth" });
    showJumpMarker(pageElement, ratio);
    flashRef(anchor, "gsr-table-ref-jumped");

    setTimeout(function () {
      if (state.heldPage === table.page) {
        releaseHeldPage();
      }
    }, 2000);
  }

  function copyPageCanvas(source, rotation) {
    const scale = Math.min(1, MAX_PREVIEW_EDGE / Math.max(source.width, source.height));
    const normalizedRotation = ((Number(rotation) || 0) % 360 + 360) % 360;
    const swapAxes = normalizedRotation === 90 || normalizedRotation === 270;
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round((swapAxes ? source.height : source.width) * scale));
    canvas.height = Math.max(1, Math.round((swapAxes ? source.width : source.height) * scale));
    const context = canvas.getContext("2d", { alpha: false });
    if (normalizedRotation === 90) {
      context.translate(canvas.width, 0);
      context.rotate(Math.PI / 2);
      context.drawImage(source, 0, 0, canvas.height, canvas.width);
      return canvas;
    }
    if (normalizedRotation === 180) {
      context.translate(canvas.width, canvas.height);
      context.rotate(Math.PI);
      context.drawImage(source, 0, 0, canvas.width, canvas.height);
      return canvas;
    }
    if (normalizedRotation === 270) {
      context.translate(0, canvas.height);
      context.rotate(-Math.PI / 2);
      context.drawImage(source, 0, 0, canvas.height, canvas.width);
      return canvas;
    }
    context.drawImage(source, 0, 0, canvas.width, canvas.height);
    return canvas;
  }

  function normalizePreviewAngle(angle) {
    let degrees = Math.abs((Number(angle) || 0) * 180 / Math.PI) % 180;
    if (degrees > 90) {
      degrees = 180 - degrees;
    }
    return degrees;
  }

  function measureAttachmentTextOrientation(items, top, bottom) {
    let horizontalWeight = 0;
    let positiveVerticalWeight = 0;
    let negativeVerticalWeight = 0;
    for (const item of items || []) {
      if (!item || !item.text || !item.text.trim()) {
        continue;
      }
      const itemBottom = item.top + item.height;
      if (Number.isFinite(top) && itemBottom < top) {
        continue;
      }
      if (Number.isFinite(bottom) && item.top > bottom) {
        continue;
      }
      const rawAngle = Number(item.angle) || 0;
      const angle = normalizePreviewAngle(rawAngle);
      const weight = Math.max(1, item.width * item.height) * Math.max(1, item.text.trim().length);
      if (Math.abs(angle - 90) <= 18) {
        if (rawAngle >= 0) {
          positiveVerticalWeight += weight;
        } else {
          negativeVerticalWeight += weight;
        }
      } else if (angle <= 18) {
        horizontalWeight += weight;
      }
    }
    return {
      horizontalWeight,
      positiveVerticalWeight,
      negativeVerticalWeight,
      verticalWeight: positiveVerticalWeight + negativeVerticalWeight
    };
  }

  function getAttachmentPreviewRotation(pageData, table) {
    if (!pageData || !Array.isArray(pageData.items) || !pageData.items.length) {
      return 0;
    }
    if (!(pageData.height > pageData.width * 1.08)) {
      return 0;
    }
    const previewTop = Number.isFinite(table.focusTop) ? table.focusTop : table.top;
    const focusTop = Number.isFinite(previewTop) ? Math.max(0, previewTop - pageData.height * 0.08) : NaN;
    const focusBottom = Number.isFinite(previewTop) && Number.isFinite(table.height)
      ? Math.min(pageData.height, previewTop + Math.max(table.height * 10, pageData.height * 0.72))
      : NaN;
    let stats = measureAttachmentTextOrientation(pageData.items, focusTop, focusBottom);
    if (stats.verticalWeight <= 0 && stats.horizontalWeight <= 0) {
      stats = measureAttachmentTextOrientation(pageData.items);
    }
    if (stats.verticalWeight <= Math.max(stats.horizontalWeight * 1.35, 1600)) {
      return 0;
    }
    return stats.positiveVerticalWeight >= stats.negativeVerticalWeight ? 90 : 270;
  }

  function formatPreviewTitle(table) {
    const parts = [table.label];
    if (table.source === "attachment" && table.attachmentName) {
      parts.push(table.attachmentName);
    }
    parts.push("page " + table.page);
    return parts.join(" - ");
  }

  async function waitForCanvas(pageElement) {
    for (let i = 0; i < 20; i++) {
      const canvas = pageElement && pageElement.querySelector("canvas");
      if (canvas && canvas.width && canvas.height) {
        return canvas;
      }
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    return null;
  }

  function appendPreviewContent(preview, table, pageWrap, canvas) {
    const content = document.createElement("div");
    content.className = "gsr-table-preview-content";

    const caption = document.createElement("div");
    caption.className = "gsr-table-preview-caption";
    caption.textContent = table.text || table.label;

    content.append(pageWrap, caption);
    preview.title.textContent = formatPreviewTitle(table);
    preview.body.textContent = "";
    preview.body.scrollLeft = 0;
    preview.content = content;
    preview.canvas = canvas;
    preview.caption = caption;
    preview.body.appendChild(content);
    requestAnimationFrame(function () {
      syncPreviewContentLayout(preview);
    });
  }

  async function renderTable(preview, table, token) {
    if (table.source === "attachment") {
      const attachments = await getAttachmentDocs();
      if (token !== preview.token) {
        return;
      }

      const attachment = attachments.find(item => item.id === table.attachmentId);
      if (!attachment) {
        setPreviewMessage(preview, "Unable to open the PDF attachment for this table.");
        return;
      }

      const pageData = await getAttachmentTextPage(attachment, table.page);
      if (token !== preview.token) {
        return;
      }

      const baseRotation = Number.isFinite(table.pageRotation) ? table.pageRotation : getAttachmentPreviewRotation(pageData, table);
      const rotation = normalizeRotationDegrees(baseRotation + (preview.manualRotation || 0));
      const canvas = await renderAttachmentPageCanvas(attachment, table.page, rotation);
      if (token !== preview.token) {
        return;
      }
      if (!canvas) {
        setPreviewMessage(preview, "Unable to render this table attachment.");
        return;
      }

      const pageWrap = document.createElement("div");
      pageWrap.className = "gsr-table-preview-page";
      if (rotation) {
        pageWrap.classList.add("gsr-rotated");
      }
      pageWrap.appendChild(canvas);

      const focusTop = Number.isFinite(table.focusTop) ? table.focusTop : table.top;
      const ratio = table.pageHeight ? focusTop / table.pageHeight : 0;
      preview.currentTable = table;
      updatePreviewRotateButton(preview);
      appendPreviewContent(preview, table, pageWrap, canvas);

      requestAnimationFrame(function () {
        if (rotation) {
          preview.body.scrollTop = 0;
          return;
        }
        const target = canvas.offsetHeight * clamp(ratio, 0, 1);
        preview.body.scrollTop = Math.max(0, target - 72);
      });
      return;
    }

    const api = state.api;
    await api.ensurePage(table.page);
    try {
      if (token !== preview.token) {
        return;
      }

      const pageElement = api.getPageElement(table.page);
      const source = await waitForCanvas(pageElement);
      if (token !== preview.token) {
        return;
      }
      if (!source) {
        setPreviewMessage(preview, "Unable to render this table page.");
        return;
      }

      const baseRotation = Number.isFinite(table.pageRotation) ? table.pageRotation : 0;
      const rotation = normalizeRotationDegrees(baseRotation + (preview.manualRotation || 0));
      const canvas = copyPageCanvas(source, rotation);
      const pageWrap = document.createElement("div");
      pageWrap.className = "gsr-table-preview-page";
      if (rotation) {
        pageWrap.classList.add("gsr-rotated");
      }
      pageWrap.appendChild(canvas);

      const focusTop = Number.isFinite(table.focusTop) ? table.focusTop : table.top;
      const ratio = table.pageHeight ? focusTop / table.pageHeight : 0;
      preview.currentTable = table;
      updatePreviewRotateButton(preview);
      appendPreviewContent(preview, table, pageWrap, canvas);

      requestAnimationFrame(function () {
        if (rotation) {
          preview.body.scrollTop = 0;
          return;
        }
        const target = canvas.offsetHeight * clamp(ratio, 0, 1);
        preview.body.scrollTop = Math.max(0, target - 72);
      });
    } finally {
      try {
        api.releasePage(table.page);
      } catch (error) {
      }
    }
  }

  async function showPreview(key, label, anchor, pinned) {
    const preview = pinned ? createPinnedPreview() : ensurePreview();
    if (!pinned) {
      clearHideTimer();
    }
    preview.token++;
    const token = preview.token;
    preview.panel.classList.toggle("gsr-pinned", !!pinned);
    preview.title.textContent = label;
    setPreviewFullscreen(preview, false);
    resetPreviewRenderState(preview);
    setPreviewMessage(preview, "Finding table...");
    positionPreview(preview, anchor);

    const index = await waitForIndexWithTable(key);
    if (token !== preview.token) {
      return;
    }
    const table = findTable(index, key);
    if (!table) {
      setPreviewMessage(preview, label + " caption not found in this PDF.");
      return;
    }
    setPreviewMessage(preview, "Rendering preview...");
    await renderTable(preview, table, token);
    if (token === preview.token) {
      positionPreview(preview, anchor);
    }
  }

  async function start() {
    await ensureCurrentDocument();
    installToolbar();
    updateModeUi();
    scheduleAnnotate();
    window.addEventListener("resize", function () {
      syncAllPreviewLayouts();
    });
    window.addEventListener("mousedown", handleMouseBackNavigation, true);
    window.addEventListener("wheel", event => {
      if (event.ctrlKey) {
        invalidateRenderedLayers();
      }
    }, { capture: true, passive: true });
    window.addEventListener("keydown", event => {
      if ((event.ctrlKey || event.metaKey) && ["+", "=", "-", "0"].includes(event.key)) {
        invalidateRenderedLayers();
      }
    }, true);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
