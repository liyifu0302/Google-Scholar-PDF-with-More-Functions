(function () {
  "use strict";

  const SCRIPT_ID = "gsr-table-preview-script";
  const BUTTON_CLASS = "gsr-table-preview-loader-btn";
  const ICON = '<svg viewBox="0 0 24 24"><path d="M4 4H20V20H4V4ZM6 6V9H18V6H6ZM6 11V18H10V11H6ZM12 11V18H18V11H12Z"/></svg>';

  let loaded = false;
  let loading = false;

  function loadPreviewScript(button) {
    if (loaded || loading) {
      return;
    }
    const existing = document.getElementById(SCRIPT_ID);
    if (existing) {
      loaded = true;
      button && button.remove();
      return;
    }
    loading = true;
    if (button) {
      button.classList.add("gsr-loading");
      button.disabled = true;
      button.title = "Loading table and figure preview";
      button.setAttribute("aria-label", "Loading table and figure preview");
    }
    const script = document.createElement("script");
    script.id = SCRIPT_ID;
    script.src = "/reader-table-preview.js";
    script.defer = true;
    script.addEventListener("load", () => {
      loaded = true;
      loading = false;
      button && button.remove();
    });
    script.addEventListener("error", () => {
      loading = false;
      if (button) {
        button.disabled = false;
        button.classList.remove("gsr-loading");
        button.title = "Retry table and figure preview";
        button.setAttribute("aria-label", "Retry table and figure preview");
      }
      console.warn("Google Scholar Reader table preview: failed to load preview script");
    });
    document.head.appendChild(script);
  }

  function makeButton() {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "gsr-flat-btn gsr-stateful-btn " + BUTTON_CLASS;
    button.title = "Enable table and figure preview";
    button.setAttribute("aria-label", "Enable table and figure preview");
    button.innerHTML = ICON;
    button.addEventListener("click", () => loadPreviewScript(button));
    return button;
  }

  function syncToolbarBrandIcon() {
    const logo = document.querySelector(".gsr-tb-logo");
    if (!logo || logo.dataset.gsrBrandIcon === "true") {
      return !!logo;
    }

    const image = document.createElement("img");
    image.className = "gsr-tb-logo-image";
    image.alt = "PaperPilot";
    image.draggable = false;
    try {
      image.src = chrome.runtime.getURL("icon48.png");
    } catch (error) {
      image.src = "icon48.png";
    }

    logo.textContent = "";
    logo.appendChild(image);
    logo.dataset.gsrBrandIcon = "true";
    return true;
  }

  function installButton() {
    syncToolbarBrandIcon();
    if (loaded || loading || document.querySelector("." + BUTTON_CLASS)) {
      return true;
    }
    const toolbar = document.querySelector(".gsr-toolbar .gsr-tb-ctr");
    if (!toolbar) {
      return false;
    }
    toolbar.appendChild(makeButton());
    return true;
  }

  function start() {
    installButton();
    const observer = new MutationObserver(() => {
      const logoReady = syncToolbarBrandIcon();
      if (loaded && logoReady) {
        observer.disconnect();
        return;
      }
      installButton();
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
