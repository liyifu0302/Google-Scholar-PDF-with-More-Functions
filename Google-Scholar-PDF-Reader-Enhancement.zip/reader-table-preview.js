(function () {
  "use strict";

  const REF_RE = /\b(?:Tables?|Tabs?\.?|T\s*A\s*B\s*L\s*E)\s*([A-Z]?\d+(?:[.-]\d+)?[A-Za-z]?|[IVXLCDM]+)\b|\b(?:Figures?|Figs?\.?|F\s*I\s*G\s*U\s*R\s*E)\s*([A-Z]?\d+(?:[.-]\d+)?[A-Za-z]?|[IVXLCDM]+)\b|\b(?:Online\s+)?Appendix(?:\s+(?:Table|Figure|Fig\.?))?\s*([A-Z]\d*|[0-9]+[A-Za-z]?)\b|\u8868\s*([0-9]+|[\u4e00\u4e8c\u4e09\u56db\u4e94\u516d\u4e03\u516b\u4e5d\u5341\u767e]+)/gi;
  const CAPTION_RE = /^\s*(?:Table|Tab\.?|T\s*A\s*B\s*L\s*E)\s*([A-Z]?\d+(?:[.-]\d+)?[A-Za-z]?|[IVXLCDM]+)\b(.*)$/i;
  const FIGURE_CAPTION_RE = /^\s*(?:Figure|Fig\.?|F\s*I\s*G\s*U\s*R\s*E)\s*([A-Z]?\d+(?:[.-]\d+)?[A-Za-z]?|[IVXLCDM]+)\b(.*)$/i;
  const APPENDIX_CAPTION_RE = /^\s*(?:Online\s+)?Appendix(?:\s+(?:Table|Figure|Fig\.?))?\s*([A-Z]\d*|[0-9]+[A-Za-z]?)\b(.*)$/i;
  const CAPTION_ZH_RE = /^\s*\u8868\s*([0-9]+|[\u4e00\u4e8c\u4e09\u56db\u4e94\u516d\u4e03\u516b\u4e5d\u5341\u767e]+)(.*)$/;
  const PROSE_TABLE_TAIL_RE = /^[\s,;:.\-\u2013\u2014]*(?:(?:panel|column|columns|appendix|section|model|models)\s+[a-z0-9() ,.-]+\s+)?(?:reports?|shows?|presents?|summari[sz]es?|lists?|contains?|provides?|documents?|describes?|compares?|indicates?|suggests?|reveals?|demonstrates?|includes?|estimates?|examines?|uses?|displays?|gives?)\b/i;
  const PROSE_TABLE_SENTENCE_RE = /\b(?:reports?|shows?|presents?|summari[sz]es?|documents?|describes?|compares?|indicates?|suggests?|reveals?|demonstrates?|estimates?|examines?)\s+(?:the|that|how|my|our|their|these|those|results?|tests?|models?|analysis|statistics|descriptive|effect|effects)\b/i;
  const REFERENCE_SENTENCE_TAIL_RE = /^[\s,;:.\-\u2013\u2014]*(?:the|this|these|those|we|i|our|my|their|in|on|as|for|from|with|using|based|column|columns|panel|panels|model|models)\b/i;
  const MAX_INDEX_WORKERS = 3;
  const STORAGE_KEY = "gsr-table-ref-mode";
  const MODE_PREVIEW = "preview";
  const MODE_JUMP = "jump";

  const state = {
    api: null,
    index: null,
    indexPromise: null,
    scheduled: false,
    preview: null,
    hideTimer: 0,
    scrollTimer: 0,
    token: 0,
    pinned: false,
    heldPage: 0,
    mode: loadMode(),
    modeTools: null
  };

  function loadMode() {
    try {
      return localStorage.getItem(STORAGE_KEY) === MODE_JUMP ? MODE_JUMP : MODE_PREVIEW;
    } catch (error) {
      return MODE_PREVIEW;
    }
  }

  function saveMode() {
    try {
      localStorage.setItem(STORAGE_KEY, state.mode);
    } catch (error) {
      console.warn("Google Scholar Reader table preview: unable to save mode", error);
    }
  }

  function normalizeId(value) {
    return String(value || "")
      .trim()
      .replace(/\s+/g, "")
      .replace(/[.:;,\-\u2013\u2014]+$/g, "")
      .toLowerCase();
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function waitForApi() {
    if (window.__gsrTablePreviewApi) {
      state.api = window.__gsrTablePreviewApi;
      return Promise.resolve(state.api);
    }
    return new Promise(resolve => {
      const started = Date.now();
      const timer = setInterval(function () {
        if (window.__gsrTablePreviewApi || Date.now() - started > 15000) {
          clearInterval(timer);
          state.api = window.__gsrTablePreviewApi || null;
          resolve(state.api);
        }
      }, 100);
    });
  }

  function makeModeButton(className, mode, label, svg) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "gsr-flat-btn " + className;
    button.dataset.tableMode = mode;
    button.innerHTML = svg;
    button.setAttribute("aria-label", label);
    button.title = label;
    button.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      setMode(mode);
    });
    return button;
  }

  function installToolbar() {
    const center = document.querySelector(".gsr-tb-ctr");
    if (!center || document.querySelector(".gsr-table-mode-tools")) {
      updateModeUi();
      return;
    }

    const tools = document.createElement("span");
    tools.className = "gsr-table-mode-tools";
    const previewButton = makeModeButton(
      "gsr-table-mode-preview",
      MODE_PREVIEW,
      "Hover table, figure, and appendix references to preview",
      '<svg viewBox="0 0 21 21"><path d="M3.5 4.5H17.5V16.5H3.5V4.5ZM5 6V9H9.8V6H5ZM11.2 6V9H16V6H11.2ZM5 10.3V15H9.8V10.3H5ZM11.2 10.3V15H16V10.3H11.2Z"/><path d="M10.5 13.7C12.5 10.8 15.9 10.8 17.9 13.7C15.9 16.6 12.5 16.6 10.5 13.7ZM14.2 12.4C13.5 12.4 12.9 13 12.9 13.7C12.9 14.4 13.5 15 14.2 15C14.9 15 15.5 14.4 15.5 13.7C15.5 13 14.9 12.4 14.2 12.4Z"/></svg>'
    );
    const jumpButton = makeModeButton(
      "gsr-table-mode-jump",
      MODE_JUMP,
      "Click table, figure, and appendix references to jump",
      '<svg viewBox="0 0 21 21"><path d="M3.5 4.5H13.5V14.5H3.5V4.5ZM5 6V8.6H8V6H5ZM9.3 6V8.6H12V6H9.3ZM5 9.9V13H8V9.9H5ZM9.3 9.9V13H12V9.9H9.3Z"/><path d="M14.4 9L13.3 10.1L15.7 12.5H10V14H15.7L13.3 16.4L14.4 17.5L18.7 13.2L14.4 9Z"/></svg>'
    );

    tools.append(previewButton, jumpButton);
    center.appendChild(tools);
    state.modeTools = tools;
    updateModeUi();
  }

  function setMode(mode) {
    state.mode = mode === MODE_JUMP ? MODE_JUMP : MODE_PREVIEW;
    saveMode();
    closePreview();
    updateModeUi();
    updateRefModes();
  }

  function updateModeUi() {
    document.body.classList.toggle("gsr-table-jump-mode", state.mode === MODE_JUMP);
    document.querySelector(".gsr-root")?.classList.toggle("gsr-table-jump-mode", state.mode === MODE_JUMP);
    for (const button of document.querySelectorAll(".gsr-table-mode-tools [data-table-mode]")) {
      const selected = button.dataset.tableMode === state.mode;
      button.classList.toggle("gsr-select", selected);
      button.setAttribute("aria-pressed", selected ? "true" : "false");
    }
  }

  async function waitForDocumentReady(api) {
    const started = Date.now();
    while (api && api.numPages() <= 0 && Date.now() - started < 15000) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }

  function lineText(items) {
    let text = "";
    let previous = null;
    for (const item of items) {
      const part = item.text || "";
      if (!part) {
        continue;
      }
      if (previous && text && !/\s$/.test(text) && !/^\s/.test(part)) {
        const gap = item.left - (previous.left + previous.width);
        if (gap > Math.max(1.5, item.height * 0.16)) {
          text += " ";
        }
      }
      text += part;
      previous = item;
    }
    return text.replace(/\s+/g, " ").trim();
  }

  function mergeBounds(items) {
    let left = Infinity;
    let top = Infinity;
    let right = -Infinity;
    let bottom = -Infinity;
    for (const item of items) {
      left = Math.min(left, item.left);
      top = Math.min(top, item.top);
      right = Math.max(right, item.left + item.width);
      bottom = Math.max(bottom, item.top + item.height);
    }
    return {
      left,
      top,
      width: Math.max(0, right - left),
      height: Math.max(0, bottom - top)
    };
  }

  function makeLines(items) {
    const visible = (items || [])
      .filter(item => item.text && item.text.trim() && Number.isFinite(item.left) && Number.isFinite(item.top))
      .sort((a, b) => a.top - b.top || a.left - b.left);
    const rows = [];
    for (const item of visible) {
      const row = rows[rows.length - 1];
      const tolerance = Math.max(2, Math.min(8, Math.max(item.height || 0, row ? row.height : 0) * 0.7));
      if (row && Math.abs(item.top - row.top) <= tolerance) {
        row.items.push(item);
        row.top = (row.top * (row.items.length - 1) + item.top) / row.items.length;
        row.height = Math.max(row.height, item.height || 0);
      } else {
        rows.push({ top: item.top, height: item.height || 0, items: [item] });
      }
    }
    return rows.map(row => {
      row.items.sort((a, b) => a.left - b.left);
      return {
        text: lineText(row.items),
        bounds: mergeBounds(row.items),
        items: row.items
      };
    }).filter(line => line.text);
  }

  function makeTarget(kind, id) {
    const normalized = normalizeId(id);
    if (!normalized) {
      return null;
    }
    const labels = {
      table: "Table ",
      figure: "Figure ",
      appendix: "Appendix "
    };
    return {
      kind,
      id,
      key: kind === "table" ? normalized : kind + ":" + normalized,
      label: (labels[kind] || "") + id
    };
  }

  function cleanCaptionTail(tail) {
    return String(tail || "")
      .replace(/\(\s*continued\s*\)/ig, "")
      .replace(/\bcontinued\b/ig, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function isReferenceSentenceTail(tail) {
    const value = cleanCaptionTail(tail);
    if (!value) {
      return false;
    }
    if (/^[\s:.\-\u2013\u2014]*this\s+(?:table|figure)\s+(?:reports?|presents?|shows?|summari[sz]es?|documents?|describes?|contains?|provides?)\b/i.test(value)) {
      return false;
    }
    return PROSE_TABLE_TAIL_RE.test(value) ||
      PROSE_TABLE_SENTENCE_RE.test(value) ||
      REFERENCE_SENTENCE_TAIL_RE.test(value) ||
      /^[,;]?\s*(?:and|or|but|because|whereas|while|although|if|when|for|from|in|of|with|on|to)\b/i.test(value) ||
      /^[,;]?\s*panel\s+[a-z0-9]+\s+(?:also\s+)?(?:reports?|shows?|presents?|contains?|provides?)\b/i.test(value);
  }

  function hasStrongCaptionLead(text) {
    return /^\s*(?:TABLE|T\s+A\s+B\s+L\s+E|FIGURE|F\s+I\s+G\s+U\s+R\s+E|APPENDIX)\s+(?:[A-Z]?\d+(?:[.-]\d+)?[A-Za-z]?|[IVXLCDM]+)\b/.test(text || "");
  }

  function isAllowedStrongCaptionTail(tail) {
    const value = cleanCaptionTail(tail).replace(/^[\s:.\-\u2013\u2014]+/, "").trim();
    if (!value || value.length > 220) {
      return false;
    }
    if (PROSE_TABLE_TAIL_RE.test(value) || PROSE_TABLE_SENTENCE_RE.test(value)) {
      return false;
    }
    const words = value.split(/\s+/).filter(Boolean);
    return words.length <= 30;
  }

  function isShortCaptionTitle(text) {
    const value = cleanCaptionTail(text).replace(/^[\s:.\-\u2013\u2014]+/, "").trim();
    if (!value || value.length > 180) {
      return false;
    }
    if (isReferenceSentenceTail(value)) {
      return false;
    }
    if (/^[^.?!]{3,100}[.!?]\s+This\s+(?:table|figure)\s+/i.test(value)) {
      return true;
    }
    if (/[.!?]\s+\p{Lu}/u.test(value)) {
      return false;
    }
    const words = value.split(/\s+/).filter(Boolean);
    if (words.length > 24) {
      return false;
    }
    return true;
  }

  function nextUsefulLine(lines, index) {
    for (let i = index + 1; i < Math.min(lines.length, index + 5); i++) {
      const text = (lines[i].text || "").replace(/\s+/g, " ").trim();
      if (!text || /^\d+$/.test(text) || /^electronic copy available/i.test(text)) {
        continue;
      }
      return lines[i];
    }
    return null;
  }

  function captionCandidateScore(line, lines, index, tail) {
    const value = cleanCaptionTail(tail);
    const strongLead = hasStrongCaptionLead(line.text);
    if (isReferenceSentenceTail(value) && !(strongLead && isAllowedStrongCaptionTail(value))) {
      return -1;
    }
    const next = nextUsefulLine(lines, index);
    const nextText = next ? next.text : "";
    let score = strongLead ? 42 : 20;
    if (line.bounds && line.bounds.top < line.pageHeight * 0.22) {
      score += 18;
    }
    if (!value) {
      if (!nextText) {
        return score;
      }
      if (isShortCaptionTitle(nextText) || /^\s*this\s+(?:table|figure)\s+/i.test(nextText)) {
        score += 28;
      } else {
        score -= 12;
      }
    } else if (isShortCaptionTitle(value) || (strongLead && isAllowedStrongCaptionTail(value))) {
      score += 24;
    } else {
      return -1;
    }
    if (/^\s*this\s+(?:table|figure)\s+/i.test(nextText)) {
      score += 12;
    }
    return score;
  }

  function captionTextFor(line, lines, index, tail) {
    const value = cleanCaptionTail(tail).replace(/^[\s:.\-\u2013\u2014]+/, "").trim();
    const next = nextUsefulLine(lines, index);
    if (!value && next && (isShortCaptionTitle(next.text) || /^\s*this\s+(?:table|figure)\s+/i.test(next.text))) {
      return line.text + " " + next.text;
    }
    return line.text;
  }

  function getCaptionTarget(line, lines, index) {
    const text = line.text || "";
    const latin = CAPTION_RE.exec(text);
    if (latin) {
      const score = captionCandidateScore(line, lines, index, latin[2] || "");
      const target = makeTarget("table", latin[1]);
      if (score >= 0 && target) {
        return { ...target, score, text: captionTextFor(line, lines, index, latin[2] || "") };
      }
    }
    const figure = FIGURE_CAPTION_RE.exec(text);
    if (figure) {
      const score = captionCandidateScore(line, lines, index, figure[2] || "");
      const target = makeTarget("figure", figure[1]);
      if (score >= 0 && target) {
        return { ...target, score, text: captionTextFor(line, lines, index, figure[2] || "") };
      }
    }
    const appendix = APPENDIX_CAPTION_RE.exec(text);
    if (appendix) {
      const score = captionCandidateScore(line, lines, index, appendix[2] || "");
      const target = makeTarget("appendix", appendix[1]);
      if (score >= 0 && target) {
        return { ...target, score, text: captionTextFor(line, lines, index, appendix[2] || "") };
      }
    }
    const zh = CAPTION_ZH_RE.exec(text);
    if (zh) {
      const score = captionCandidateScore(line, lines, index, zh[2] || "");
      const target = makeTarget("table", zh[1]);
      if (score >= 0 && target) {
        return { ...target, score, text: captionTextFor(line, lines, index, zh[2] || "") };
      }
    }
    return null;
  }

  function isLikelyCaptionTail(tail) {
    return !isReferenceSentenceTail(tail) && (!cleanCaptionTail(tail) || isShortCaptionTitle(tail));
  }

  async function buildIndex() {
    if (state.index) {
      return state.index;
    }
    if (state.indexPromise) {
      return state.indexPromise;
    }
    state.indexPromise = (async function () {
      const api = await waitForApi();
      const tables = new Map();
      const pages = new Map();
      state.index = { tables, pages, numPages: 0, complete: false };
      if (!api) {
        state.index.complete = true;
        return state.index;
      }

      await waitForDocumentReady(api);
      const numPages = api.numPages();
      state.index.numPages = numPages;
      let nextPage = 1;
      async function worker() {
        while (nextPage <= numPages) {
          const pageNumber = nextPage++;
          try {
            const page = await api.getTextPage(pageNumber);
            const lines = makeLines(page.items);
            for (const line of lines) {
              line.pageHeight = page.height || 0;
              line.pageWidth = page.width || 0;
            }
            pages.set(pageNumber, { page, lines });
            for (let lineIndex = 0; lineIndex < lines.length; lineIndex++) {
              const line = lines[lineIndex];
              const target = getCaptionTarget(line, lines, lineIndex);
              if (!target) {
                continue;
              }
              if (!target.key) {
                continue;
              }
              const existing = tables.get(target.key);
              if (existing && existing.score >= target.score) {
                continue;
              }
              tables.set(target.key, {
                key: target.key,
                kind: target.kind,
                label: target.label,
                score: target.score,
                page: pageNumber,
                text: target.text || line.text,
                top: line.bounds.top,
                left: line.bounds.left,
                width: line.bounds.width,
                height: line.bounds.height,
                pageWidth: page.width,
                pageHeight: page.height
              });
            }
          } catch (error) {
            console.warn("Google Scholar Reader table preview: text index failed", pageNumber, error);
          }
        }
      }

      const workers = [];
      for (let i = 0; i < Math.min(MAX_INDEX_WORKERS, numPages); i++) {
        workers.push(worker());
      }
      await Promise.all(workers);
      state.index.complete = true;
      scheduleAnnotate();
      return state.index;
    })();
    return state.indexPromise;
  }

  async function waitForIndexWithTable(key) {
    const indexPromise = buildIndex();
    while (true) {
      const index = state.index;
      if (index && (findTable(index, key) || index.complete)) {
        return index;
      }
      const finished = await Promise.race([
        indexPromise.then(() => true),
        new Promise(resolve => setTimeout(() => resolve(false), 80))
      ]);
      if (finished) {
        return state.index;
      }
    }
  }

  function getRefMatches(text) {
    const matches = [];
    REF_RE.lastIndex = 0;
    let match;
    while ((match = REF_RE.exec(text))) {
      const tableId = match[1] || match[4];
      const figureId = match[2];
      const appendixId = match[3];
      const target = tableId ? makeTarget("table", tableId) :
        figureId ? makeTarget("figure", figureId) :
        appendixId ? makeTarget("appendix", appendixId) : null;
      if (!target) {
        continue;
      }
      matches.push({
        key: target.key,
        id: target.id,
        kind: target.kind,
        label: target.label,
        start: match.index,
        end: match.index + match[0].length
      });
    }
    return matches;
  }

  function getMatchRect(span, match) {
    const node = span.firstChild;
    if (!node || node.nodeType !== Node.TEXT_NODE) {
      return span.getBoundingClientRect();
    }
    const range = document.createRange();
    range.setStart(node, Math.min(match.start, node.length));
    range.setEnd(node, Math.min(match.end, node.length));
    const rects = Array.from(range.getClientRects()).filter(rect => rect.width > 0 && rect.height > 0);
    const rect = rects[0] || range.getBoundingClientRect();
    range.detach();
    return rect;
  }

  function mergeClientRects(rects) {
    let left = Infinity;
    let top = Infinity;
    let right = -Infinity;
    let bottom = -Infinity;
    for (const rect of rects) {
      left = Math.min(left, rect.left);
      top = Math.min(top, rect.top);
      right = Math.max(right, rect.right);
      bottom = Math.max(bottom, rect.bottom);
    }
    return {
      left,
      top,
      right,
      bottom,
      width: Math.max(0, right - left),
      height: Math.max(0, bottom - top)
    };
  }

  function makeDomLines(textLayer) {
    const spans = Array.from(textLayer.querySelectorAll(".gsr-text:not(.gsr-hide)"))
      .map(span => ({
        span,
        text: span.textContent || "",
        rect: span.getBoundingClientRect()
      }))
      .filter(item => item.text.trim() && item.rect.width > 0 && item.rect.height > 0)
      .sort((a, b) => a.rect.top - b.rect.top || a.rect.left - b.rect.left);

    const rows = [];
    for (const item of spans) {
      const row = rows[rows.length - 1];
      const tolerance = Math.max(2, Math.min(8, Math.max(item.rect.height || 0, row ? row.height : 0) * 0.7));
      if (row && Math.abs(item.rect.top - row.top) <= tolerance) {
        row.items.push(item);
        row.top = (row.top * (row.items.length - 1) + item.rect.top) / row.items.length;
        row.height = Math.max(row.height, item.rect.height || 0);
      } else {
        rows.push({ top: item.rect.top, height: item.rect.height || 0, items: [item] });
      }
    }

    return rows.map(row => {
      row.items.sort((a, b) => a.rect.left - b.rect.left);
      let text = "";
      let previous = null;
      const parts = [];
      const rects = [];
      for (const item of row.items) {
        if (previous && text && !/\s$/.test(text) && !/^\s/.test(item.text)) {
          const gap = item.rect.left - previous.rect.right;
          if (gap > Math.max(1.5, item.rect.height * 0.16)) {
            text += " ";
          }
        }
        const start = text.length;
        text += item.text;
        parts.push({
          span: item.span,
          text: item.text,
          start,
          end: text.length
        });
        rects.push(item.rect);
        previous = item;
      }
      return {
        text,
        parts,
        bounds: mergeClientRects(rects)
      };
    }).filter(line => line.text.trim());
  }

  function rectFromDomLine(line, start, end) {
    const rects = [];
    for (const part of line.parts) {
      if (part.end <= start || part.start >= end) {
        continue;
      }
      const localStart = Math.max(0, start - part.start);
      const localEnd = Math.min(part.text.length, end - part.start);
      if (localStart < localEnd) {
        const rect = getMatchRect(part.span, { start: localStart, end: localEnd });
        if (rect.width > 0 && rect.height > 0) {
          rects.push(rect);
        }
      }
    }
    return rects.length ? mergeClientRects(rects) : null;
  }

  function ensureLayer(page) {
    let layer = page.querySelector(":scope > .gsr-table-ref-layer");
    if (!layer) {
      layer = document.createElement("div");
      layer.className = "gsr-table-ref-layer";
      page.appendChild(layer);
    }
    return layer;
  }

  function raiseLayer(page, layer) {
    if (layer && layer.nextElementSibling) {
      page.appendChild(layer);
    }
  }

  function updateRefButton(button, label) {
    const action = state.mode === MODE_JUMP ? "Jump to " : "Preview ";
    button.setAttribute("aria-label", action + label);
    button.title = action + label;
  }

  function updateRefModes() {
    for (const button of document.querySelectorAll(".gsr-table-ref")) {
      updateRefButton(button, button.dataset.tableLabel || "table");
    }
  }

  function annotatePage(page) {
    const textLayer = page.querySelector(".gsr-text-ctn");
    if (!textLayer) {
      return;
    }
    const signature = [
      textLayer.children.length,
      textLayer.textContent.length,
      page.clientWidth,
      page.clientHeight
    ].join(":");
    const existingLayer = page.querySelector(":scope > .gsr-table-ref-layer");
    if (existingLayer && existingLayer.dataset.signature === signature) {
      return;
    }
    const layer = ensureLayer(page);
    layer.dataset.signature = signature;
    layer.textContent = "";
    const pageRect = page.getBoundingClientRect();
    for (const line of makeDomLines(textLayer)) {
      const matches = getRefMatches(line.text || "");
      for (const match of matches) {
        const rect = rectFromDomLine(line, match.start, match.end);
        if (!rect || !rect.width || !rect.height) {
          continue;
        }
        const button = document.createElement("button");
        button.type = "button";
        button.className = "gsr-table-ref";
        button.dataset.tableKey = match.key;
        button.dataset.tableLabel = match.label;
        updateRefButton(button, match.label);
        button.style.left = rect.left - pageRect.left + "px";
        button.style.top = rect.top - pageRect.top + "px";
        button.style.width = Math.max(18, rect.width) + "px";
        button.style.height = Math.max(14, rect.height) + "px";
        button.addEventListener("pointerenter", event => {
          if (state.mode !== MODE_PREVIEW) {
            return;
          }
          clearHideTimer();
          showPreview(match.key, match.label, event.currentTarget, false);
        });
        button.addEventListener("focus", event => {
          if (state.mode !== MODE_PREVIEW) {
            return;
          }
          clearHideTimer();
          showPreview(match.key, match.label, event.currentTarget, false);
        });
        button.addEventListener("pointerleave", scheduleHide);
        button.addEventListener("click", event => {
          event.preventDefault();
          event.stopPropagation();
          if (state.mode === MODE_JUMP) {
            jumpToTable(match.key, match.label, event.currentTarget);
          } else {
            showPreview(match.key, match.label, event.currentTarget, true);
          }
        });
        layer.appendChild(button);
      }
    }
    raiseLayer(page, layer);
  }

  function isPageNearViewport(page) {
    const rect = page.getBoundingClientRect();
    const margin = Math.max(900, window.innerHeight * 1.25);
    return rect.bottom >= -margin && rect.top <= window.innerHeight + margin;
  }

  function annotateRenderedRefs() {
    for (const page of document.querySelectorAll(".gsr-page")) {
      if (isPageNearViewport(page)) {
        annotatePage(page);
      }
    }
  }

  function scheduleAnnotate() {
    if (state.scheduled) {
      return;
    }
    state.scheduled = true;
    const run = function () {
      if (!state.scheduled) {
        return;
      }
      state.scheduled = false;
      installToolbar();
      annotateRenderedRefs();
      updateRefModes();
    };
    requestAnimationFrame(run);
    setTimeout(run, 100);
  }

  function scheduleScrollAnnotate() {
    if (state.scrollTimer) {
      return;
    }
    state.scrollTimer = setTimeout(function () {
      state.scrollTimer = 0;
      scheduleAnnotate();
    }, 220);
  }

  function nodeTouchesPage(node) {
    if (!(node instanceof Element)) {
      return false;
    }
    if (node.closest(".gsr-table-preview, .gsr-table-ref-layer, .gsr-table-mode-tools")) {
      return false;
    }
    return node.classList.contains("gsr-page") ||
      node.classList.contains("gsr-text-ctn") ||
      node.classList.contains("gsr-text") ||
      !!node.querySelector(".gsr-page, .gsr-text-ctn, .gsr-text");
  }

  function handleMutations(mutations) {
    for (const mutation of mutations) {
      if (mutation.target instanceof Element &&
          mutation.target.closest(".gsr-table-preview, .gsr-table-ref-layer, .gsr-table-mode-tools")) {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (nodeTouchesPage(node)) {
          scheduleAnnotate();
          return;
        }
      }
      for (const node of mutation.removedNodes) {
        if (nodeTouchesPage(node)) {
          scheduleAnnotate();
          return;
        }
      }
    }
  }

  function clearHideTimer() {
    if (state.hideTimer) {
      clearTimeout(state.hideTimer);
      state.hideTimer = 0;
    }
  }

  function scheduleHide() {
    clearHideTimer();
    if (state.pinned) {
      return;
    }
    state.hideTimer = setTimeout(closePreview, 250);
  }

  function releaseHeldPage() {
    if (state.heldPage && state.api) {
      try {
        state.api.releasePage(state.heldPage);
      } catch (error) {
        console.warn("Google Scholar Reader table preview: release failed", error);
      }
    }
    state.heldPage = 0;
  }

  function ensurePreview() {
    if (state.preview) {
      return state.preview;
    }
    const panel = document.createElement("div");
    panel.className = "gsr-table-preview";
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-label", "Table preview");

    const header = document.createElement("div");
    header.className = "gsr-table-preview-header";
    const title = document.createElement("div");
    title.className = "gsr-table-preview-title";
    const close = document.createElement("button");
    close.type = "button";
    close.className = "gsr-table-preview-action gsr-table-preview-close";
    close.setAttribute("aria-label", "Close table preview");
    close.title = "Close";
    close.innerHTML = '<svg viewBox="0 0 21 21"><path d="M16.6 5.6L15.3 4.3L10.5 9.2L5.6 4.3L4.3 5.6L9.2 10.5L4.3 15.3L5.6 16.6L10.5 11.7L15.3 16.6L16.6 15.3L11.7 10.5L16.6 5.6Z"/></svg>';
    const fullscreen = document.createElement("button");
    fullscreen.type = "button";
    fullscreen.className = "gsr-table-preview-action gsr-table-preview-fullscreen";
    fullscreen.setAttribute("aria-label", "Full screen table preview");
    fullscreen.setAttribute("aria-pressed", "false");
    fullscreen.title = "Full screen";
    fullscreen.innerHTML = '<svg viewBox="0 0 21 21"><path d="M4 9V4H9V5.5H6.6L9.6 8.5L8.5 9.6L5.5 6.6V9H4ZM12 4H17V9H15.5V6.6L12.5 9.6L11.4 8.5L14.4 5.5H12V4ZM4 12H5.5V14.4L8.5 11.4L9.6 12.5L6.6 15.5H9V17H4V12ZM15.5 12H17V17H12V15.5H14.4L11.4 12.5L12.5 11.4L15.5 14.4V12Z"/></svg>';
    header.append(title, fullscreen, close);

    const body = document.createElement("div");
    body.className = "gsr-table-preview-body";
    panel.append(header, body);
    document.body.appendChild(panel);

    panel.addEventListener("pointerenter", clearHideTimer);
    panel.addEventListener("pointerleave", scheduleHide);
    close.addEventListener("click", event => {
      event.preventDefault();
      closePreview();
    });
    fullscreen.addEventListener("click", event => {
      event.preventDefault();
      togglePreviewFullscreen();
    });
    document.addEventListener("keydown", event => {
      if (event.key === "Escape") {
        closePreview();
      }
    });
    document.addEventListener("pointerdown", event => {
      const target = event.target;
      const inTableRef = target instanceof Element && target.closest(".gsr-table-ref");
      if (state.pinned && !panel.contains(target) && !inTableRef) {
        closePreview();
      }
    }, true);

    state.preview = { panel, title, body, fullscreen };
    return state.preview;
  }

  function setPreviewFullscreen(enabled) {
    if (!state.preview) {
      return;
    }
    state.preview.panel.classList.toggle("gsr-fullscreen", enabled);
    state.preview.fullscreen.setAttribute("aria-pressed", enabled ? "true" : "false");
    state.preview.fullscreen.title = enabled ? "Exit full screen" : "Full screen";
    state.preview.fullscreen.setAttribute("aria-label", enabled ? "Exit full screen table preview" : "Full screen table preview");
  }

  function togglePreviewFullscreen() {
    if (!state.preview) {
      return;
    }
    setPreviewFullscreen(!state.preview.panel.classList.contains("gsr-fullscreen"));
  }

  function setPreviewMessage(message) {
    const preview = ensurePreview();
    preview.body.textContent = "";
    const status = document.createElement("div");
    status.className = "gsr-table-preview-status";
    status.textContent = message;
    preview.body.appendChild(status);
  }

  function positionPreview(anchor) {
    const preview = ensurePreview();
    const panel = preview.panel;
    const anchorRect = anchor.getBoundingClientRect();
    panel.style.left = "12px";
    panel.style.top = "12px";
    panel.classList.add("gsr-vis");
    if (panel.classList.contains("gsr-fullscreen")) {
      return;
    }
    const panelRect = panel.getBoundingClientRect();
    const left = clamp(anchorRect.left, 12, window.innerWidth - panelRect.width - 12);
    let top = anchorRect.bottom + 10;
    if (top + panelRect.height > window.innerHeight - 12) {
      top = Math.max(12, anchorRect.top - panelRect.height - 10);
    }
    panel.style.left = left + "px";
    panel.style.top = top + "px";
  }

  function closePreview() {
    clearHideTimer();
    state.token++;
    state.pinned = false;
    releaseHeldPage();
    if (state.preview) {
      state.preview.panel.classList.remove("gsr-vis", "gsr-pinned", "gsr-fullscreen");
      setPreviewFullscreen(false);
      state.preview.body.textContent = "";
    }
  }

  function findTable(index, key) {
    if (index.tables.has(key)) {
      return index.tables.get(key);
    }
    if (key.includes(":")) {
      return null;
    }
    const simple = key.replace(/[a-z]$/i, "");
    return simple && index.tables.get(simple) || null;
  }

  function flashRef(anchor, className) {
    anchor.classList.add(className);
    setTimeout(function () {
      anchor.classList.remove(className);
    }, 1200);
  }

  function showJumpMarker(pageElement, ratio) {
    let marker = pageElement.querySelector(":scope > .gsr-table-jump-marker");
    if (!marker) {
      marker = document.createElement("div");
      marker.className = "gsr-table-jump-marker";
      pageElement.appendChild(marker);
    }
    marker.style.top = clamp(ratio * 100, 0, 99) + "%";
    marker.classList.remove("gsr-vis");
    marker.getBoundingClientRect();
    marker.classList.add("gsr-vis");
    clearTimeout(marker._gsrTimer);
    marker._gsrTimer = setTimeout(function () {
      marker.classList.remove("gsr-vis");
    }, 2200);
  }

  async function jumpToTable(key, label, anchor) {
    clearHideTimer();
    closePreview();
    const api = state.api || await waitForApi();
    if (!api) {
      flashRef(anchor, "gsr-table-ref-missing");
      return;
    }

    const token = ++state.token;
    const index = await waitForIndexWithTable(key);
    if (token !== state.token) {
      return;
    }
    const table = findTable(index, key);
    if (!table) {
      flashRef(anchor, "gsr-table-ref-missing");
      return;
    }

    releaseHeldPage();
    state.heldPage = table.page;
    await api.ensurePage(table.page);
    if (token !== state.token) {
      releaseHeldPage();
      return;
    }

    const pageElement = api.getPageElement(table.page);
    const scrollElement = api.getScrollElement() || document.querySelector(".gsr-body");
    if (!pageElement || !scrollElement) {
      flashRef(anchor, "gsr-table-ref-missing");
      releaseHeldPage();
      return;
    }

    const ratio = clamp(table.pageHeight ? table.top / table.pageHeight : 0, 0, 1);
    const offset = Math.min(140, scrollElement.clientHeight * 0.22);
    const top = Math.max(0, pageElement.offsetTop + pageElement.offsetHeight * ratio - offset);
    scrollElement.scrollTo({ top, left: scrollElement.scrollLeft, behavior: "smooth" });
    showJumpMarker(pageElement, ratio);
    flashRef(anchor, "gsr-table-ref-jumped");

    setTimeout(function () {
      if (state.heldPage === table.page) {
        releaseHeldPage();
      }
    }, 2000);
  }

  function copyPageCanvas(source) {
    const scale = Math.min(1, 2200 / Math.max(source.width, source.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(source.width * scale));
    canvas.height = Math.max(1, Math.round(source.height * scale));
    const context = canvas.getContext("2d", { alpha: false });
    context.drawImage(source, 0, 0, canvas.width, canvas.height);
    return canvas;
  }

  async function waitForCanvas(pageElement) {
    for (let i = 0; i < 20; i++) {
      const canvas = pageElement && pageElement.querySelector("canvas");
      if (canvas && canvas.width && canvas.height) {
        return canvas;
      }
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    return null;
  }

  async function renderTable(table, token) {
    const preview = ensurePreview();
    const api = state.api;
    releaseHeldPage();
    state.heldPage = table.page;
    await api.ensurePage(table.page);
    if (token !== state.token) {
      releaseHeldPage();
      return;
    }

    const pageElement = api.getPageElement(table.page);
    const source = await waitForCanvas(pageElement);
    if (token !== state.token) {
      releaseHeldPage();
      return;
    }
    if (!source) {
      setPreviewMessage("Unable to render this table page.");
      return;
    }

    const canvas = copyPageCanvas(source);
    const pageWrap = document.createElement("div");
    pageWrap.className = "gsr-table-preview-page";
    pageWrap.appendChild(canvas);

    const ratio = table.pageHeight ? table.top / table.pageHeight : 0;

    const caption = document.createElement("div");
    caption.className = "gsr-table-preview-caption";
    caption.textContent = table.text || table.label;

    preview.title.textContent = table.label + " - page " + table.page;
    preview.body.textContent = "";
    preview.body.append(pageWrap, caption);

    requestAnimationFrame(function () {
      const target = canvas.offsetHeight * clamp(ratio, 0, 1);
      preview.body.scrollTop = Math.max(0, target - 72);
    });
  }

  async function showPreview(key, label, anchor, pinned) {
    const preview = ensurePreview();
    clearHideTimer();
    state.pinned = !!pinned;
    state.token++;
    const token = state.token;
    preview.panel.classList.toggle("gsr-pinned", state.pinned);
    preview.title.textContent = label;
    setPreviewMessage("Finding table...");
    positionPreview(anchor);

    const index = await waitForIndexWithTable(key);
    if (token !== state.token) {
      return;
    }
    const table = findTable(index, key);
    if (!table) {
      setPreviewMessage(label + " caption not found in this PDF.");
      return;
    }
    setPreviewMessage("Rendering preview...");
    await renderTable(table, token);
    if (token === state.token) {
      positionPreview(anchor);
    }
  }

  async function start() {
    await waitForApi();
    installToolbar();
    updateModeUi();
    scheduleAnnotate();
    buildIndex().catch(error => {
      console.warn("Google Scholar Reader table preview: index failed", error);
    });
    new MutationObserver(handleMutations).observe(document.body, { childList: true, subtree: true });
    window.addEventListener("resize", scheduleAnnotate);
    window.addEventListener("scroll", scheduleScrollAnnotate, { capture: true, passive: true });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
